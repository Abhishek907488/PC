# PC SERVICES — Business Management System (Incremental Upgrade)

This package extends the `PC_Services_Personal_Web_Invoice_System_PRODUCT_MASTER_v1` base. It keeps the existing public home page, single Admin/Customer login, company-isolated customer portal, GST-percentage invoices, PDF generation and product price auto-fill/edit behavior.

## New features in this increment

- **Business dashboard:** total sales, current-month sales, total GST on sales, purchases recorded, outstanding balance, and estimated gross profit where sale-time product cost is available.
- **Separate Product List and Product Master:** searchable operational stock list and a separate product master page; opening stock is written to the stock ledger.
- **Inventory and purchases:** purchase register, vendor/supplier master, weighted-average purchase cost recalculated on each purchase, automatic stock inward, sale stock deduction, negative-stock warnings, and stock movement history/export.
- **Customer invoices and payments:** invoice register search/customer filter, admin editing of issued invoices, audit history, separate payment entries, partial/paid/pending status calculation, payment reversal with audit history, and customer portal payment history.
- **Quotations:** quote register, GST selection (CGST+SGST or IGST), PDF generation, print view, email with PDF attachment, and accepted-quote-to-invoice conversion.
- **Rental management:** rental equipment master, contracts, monthly draft billing queue, editable draft amounts/GST, and a separate Admin action to issue each invoice after review; returning equipment changes it back to Available.
- **Repair/service:** service category master, employee/technician master, service jobs, assigned technician, parts/labour values, status updates, and warranty dates.
- **Website Get a Quote:** requests are stored in the database; admin notification and customer confirmation are attempted; request status can be tracked in the admin panel.
- **Reports and logs:** April–March FY summary, Excel-compatible CSV exports, email delivery logs, and audit history.
- **Masters navigation:** all separate masters grouped under one expandable “Masters” sidebar menu without merging their underlying records or pages.
- **Backup & Restore:** Admin-only dated ZIP snapshots with consistent SQLite backup, uploads and generated PDFs; manual backup, history, download and integrity-checked restore. Backup history is never automatically pruned.
- **Staff access:** User Setup can create Staff/Technician logins and choose their module permissions. User Setup, Settings, email logs, audit history, rental billing issuance and warranty reminders remain Admin-only.
- **SMTP password handling:** saved SMTP passwords are encrypted at rest when the `cryptography` dependency is installed. The encryption key is held in `instance/secret.key` unless `SECRET_KEY` is configured in the environment. Keep that key stable and backed up.
- **Safety:** the first migration of an existing database automatically creates a backup in `backups/`; schema changes are incremental and do not intentionally reset existing records.

## Install and run

1. Install Python 3.11+ (Python 3.12/3.13 is recommended for broad package compatibility).
2. Open a terminal in this folder and run:

   ```bash
   python -m pip install -r requirements.txt
   python app.py
   ```

3. Open `http://127.0.0.1:5000` on the server PC. For LAN access, use `http://SERVER-LAN-IP:5000` and allow the port in the host firewall.
4. Default initial Admin credentials: `admin` / `admin123`. Change this password immediately before production use.
5. Configure GoDaddy SMTP in **Settings**, save the host/port/security/username/password, and send a test email. Quote email delivery cannot succeed until valid SMTP credentials are configured.

## Important data migration instruction

The ZIP intentionally does **not** contain a database. Before using this package to upgrade an existing installation, back up the old `pc_services.db`, then copy that database into this project folder before the first run. The app will create an additional pre-migration backup under `backups/` when it detects an older schema. Do not delete the original project folder or its database until you have verified the upgrade.

Keep `instance/secret.key` with the upgraded project; losing/changing the key can prevent decryption of stored SMTP credentials and can invalidate existing sessions. If `SECRET_KEY` is supplied through the environment, keep its value stable across restarts.

## Backup retention and hosting note

Daily backups are scheduled for 2:00 AM while the Python process is alive, and the app also supports manual backups. Backup files are never automatically deleted. Set `PC_SERVICES_BACKUP_DIR` to a persistent disk path for hosted deployments. Render ephemeral filesystems can be lost during deploy/restart, and a thread in a sleeping/stopped service cannot guarantee the daily schedule; use Render Cron Jobs or another external scheduler plus persistent/external storage for a production guarantee. Permanent retention requires enough storage capacity and a monitored separate copy.

## Accounting behavior and limits

- Estimated gross profit means taxable line amount minus the weighted-average product cost captured when that invoice line was saved. It excludes salaries, rent, overheads and other expenses. Older invoice lines without cost snapshots are excluded rather than guessed.
- The dashboard's GST metric is **GST on sales**, not final government GST payable.
- Negative stock is permitted by the requested policy and is shown with a warning.
- Rental billing is prepared as a draft queue. An Admin reviews/edits each draft and explicitly issues the invoice.
- Quotation data is summary-level in this increment (one scope/description and one taxable amount); itemized quote lines and richer quotation workflows can be added in a later increment.
- CSV exports open in Excel. Native `.xlsx` workbook formatting and broader date-filtered report suites can be added in a later increment.
- SMTP connection/delivery was not tested against a real GoDaddy mailbox in this environment; configure and test it from Settings.

## Testing performed for this package

- Python syntax compilation passed.
- All 20 Jinja templates parsed successfully.
- Isolated workflow tests passed for schema initialization, weighted-average purchase costing, stock inward/outward, PDF generation, invoice edit/audit, quotation GST and conversion, rental billing review/issue, public quote request storage and email-failure logging, staff permissions, and CSV export routing.
- The current tool environment did not have Flask/Werkzeug installed, so a live browser/server smoke test was not possible here. Install the listed requirements and test in your environment before production use.
