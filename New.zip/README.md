# PC SERVICES Personal Web + Invoice System

## Current features
- Public PC Services website
- Admin login and dashboard
- Customer Master
- Invoice creation with line items, GST and status
- Automatic invoice PDF generation and PDF download
- Email invoice with PDF attachment
- Company / SMTP / signature settings
- **User Setup** for creating custom Admin and Customer logins
- **Customer Portal**: each customer can log in and see only their own invoices, invoice line-item details, totals, status and download PDF

## Initial admin login
- Username: `admin`
- Password: `admin123`

Change the admin password from **User Setup** after first login.

## Customer login setup
1. Admin login.
2. Open **Customers** and create the customer.
3. Open **User Setup**.
4. Select **Customer** role.
5. Select the customer, enter any username and password, and create the login.
6. Give that username/password to the customer.
7. Customer can open `/customer/login` and access only their own invoices.

## Notes
- Existing SQLite data is preserved. The `users` table is added automatically when the application starts.
- Existing invoices remain linked to their existing customer IDs.
- Customer PDF access is protected server-side; a customer cannot open another customer's invoice by changing the invoice ID in the URL.
- PDF generation still uses the existing automatic generation/regeneration flow.
- Before production deployment, change the default admin password and set a strong SECRET_KEY.


## Login model (v3)
There is now one login screen for both Customer and Admin users: `/login`. The public website shows one **Customer / Admin Login** button. The entered account determines the destination automatically: linked customer accounts go to the customer portal and can only access that linked company's invoices/details/PDFs; admin accounts go to the admin dashboard. The old `/admin/login` and `/customer/login` URLs remain as compatibility aliases to the same unified login screen.
