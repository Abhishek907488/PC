# PC SERVICES – Product / Item Master Update

This version is built incrementally on top of the GST percentage LOCKED version.

## Added
- Admin sidebar: Product / Stock Master
- Product fields: name, category, brand, model, part no., serial no., purchase price, selling price, GST %, stock quantity, warranty, vendor
- Active/Disabled product status
- Invoice item product selector: selecting a saved product auto-fills product name and selling price
- Manual invoice items remain supported
- Invoice item stores the linked product ID when a saved product is selected
- Existing single login, company-wise customer access, GST percentage calculation, invoice and PDF functions are preserved

## Important
Product stock quantity is recorded in Product Master in this phase. Automatic stock deduction on a completed sale is intentionally reserved for the next Sales/Stock phase, so existing invoice behavior is not changed unexpectedly.

## Default admin
Username: admin
Password: admin123
Change the password before production use.
