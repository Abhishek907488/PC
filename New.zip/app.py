
import os, sqlite3, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.lib.units import mm
import smtplib
from email.message import EmailMessage
from xml.sax.saxutils import escape

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "pc_services.db")
UPLOADS = os.path.join(BASE, "static", "uploads")
INVOICE_DIR = os.path.join(BASE, "invoices")
FONT_REG = "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf"
if os.path.exists(FONT_REG):
    pdfmetrics.registerFont(TTFont("NotoSans", FONT_REG))
if os.path.exists(FONT_BOLD):
    pdfmetrics.registerFont(TTFont("NotoSans-Bold", FONT_BOLD))
PDF_FONT = "NotoSans" if os.path.exists(FONT_REG) else "Helvetica"
PDF_FONT_BOLD = "NotoSans-Bold" if os.path.exists(FONT_BOLD) else "Helvetica-Bold"
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(INVOICE_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(32))
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT
    );
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_name TEXT NOT NULL, contact_person TEXT, mobile TEXT, email TEXT,
        gstin TEXT, billing_address TEXT, shipping_address TEXT, state TEXT,
        notes TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_no TEXT UNIQUE NOT NULL, customer_id INTEGER NOT NULL,
        invoice_date TEXT NOT NULL, subtotal REAL DEFAULT 0,
        cgst REAL DEFAULT 0, sgst REAL DEFAULT 0, igst REAL DEFAULT 0,
        total REAL DEFAULT 0, status TEXT DEFAULT 'Pending',
        pdf_path TEXT, signed_at TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'customer',
        customer_id INTEGER,
        full_name TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    CREATE TABLE IF NOT EXISTS invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL, description TEXT NOT NULL,
        qty REAL DEFAULT 1, rate REAL DEFAULT 0, amount REAL DEFAULT 0,
        FOREIGN KEY(invoice_id) REFERENCES invoices(id)
    );
    """)
    defaults = {
        "company_name": "PC SERVICES",
        "company_email": "Ranveer@pcservicess.com",
        "company_phone": "+91 9977607027",
        "company_address": "EM-325 B Indus Town II Pithampur 454775, Madhya Pradesh, India",
        "gstin": "",
        "invoice_prefix": "INV",
        "email_signature": "Regards,\nRanveer\nPC SERVICES\nRanveer@pcservicess.com",
        "email_subject": "Invoice {invoice_no} from PC SERVICES",
        "email_body": "Dear {customer},\n\nPlease find attached your invoice {invoice_no}.\n\nThank you for your business.",
        "smtp_host": "",
        "smtp_port": "587",
        "smtp_user": "Ranveer@pcservicess.com",
        "smtp_password": "",
        "smtp_security": "STARTTLS",
        "signature_image": "logo.png",
    }
    # Create the initial admin account if the users table is empty.
    existing_admin = c.execute("SELECT id FROM users WHERE role='admin' LIMIT 1").fetchone()
    if not existing_admin:
        c.execute("INSERT OR IGNORE INTO users(username,password_hash,role,full_name,active,created_at) VALUES(?,?,?,?,?,?)",
                  ("admin", generate_password_hash("admin123"), "admin", "Administrator", 1, datetime.now().isoformat(timespec="seconds")))
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    c.commit()
    c.close()

def settings():
    c = db()
    rows = c.execute("SELECT key,value FROM settings").fetchall()
    c.close()
    return {r["key"]: r["value"] for r in rows}

def set_setting(k, v):
    c = db()
    c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
    c.commit(); c.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if session.get("role") != "admin":
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def customer_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if session.get("role") != "customer" or not session.get("customer_id"):
            return redirect(url_for("customer_login"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login", methods=["GET","POST"])
@app.route("/admin/login", methods=["GET","POST"])
@app.route("/customer/login", methods=["GET","POST"])
def login():
    """Single login screen for both Admin and Customer users."""
    init_db()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        c = db()
        user = c.execute("SELECT u.*, c.company_name FROM users u LEFT JOIN customers c ON c.id=u.customer_id WHERE u.username=? AND u.active=1", (username,)).fetchone()
        c.close()
        if user and check_password_hash(user["password_hash"], password):
            # Customer users must always be linked to one valid customer.
            if user["role"] == "customer":
                if not user["customer_id"] or not user["company_name"]:
                    flash("This customer login is not linked to a company. Please contact PC SERVICES.", "error")
                    return render_template("login.html")
                session.clear()
                session["user_id"] = user["id"]
                session["role"] = "customer"
                session["customer_id"] = int(user["customer_id"])
                session["username"] = user["username"]
                session["customer_company"] = user["company_name"]
                return redirect(url_for("customer_dashboard"))
            if user["role"] == "admin":
                session.clear()
                session["user_id"] = user["id"]
                session["role"] = "admin"
                session["admin"] = True
                session["username"] = user["username"]
                return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
@app.route("/admin/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/admin")
@login_required
def dashboard():
    c = db()
    customers = c.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"]
    invoices = c.execute("SELECT COUNT(*) n FROM invoices").fetchone()["n"]
    pending = c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices WHERE status!='Paid'").fetchone()["n"]
    sales = c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices WHERE strftime('%Y-%m', invoice_date)=strftime('%Y-%m','now')").fetchone()["n"]
    recent = c.execute("""SELECT i.*, c.company_name FROM invoices i JOIN customers c ON c.id=i.customer_id
                          ORDER BY i.id DESC LIMIT 8""").fetchall()
    c.close()
    return render_template("dashboard.html", customers=customers, invoices=invoices, pending=pending, sales=sales, recent=recent)

@app.route("/admin/customers", methods=["GET","POST"])
@login_required
def customers():
    c = db()
    if request.method == "POST":
        c.execute("""INSERT INTO customers(company_name,contact_person,mobile,email,gstin,billing_address,
                    shipping_address,state,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)""", (
            request.form["company_name"], request.form.get("contact_person",""),
            request.form.get("mobile",""), request.form.get("email",""),
            request.form.get("gstin",""), request.form.get("billing_address",""),
            request.form.get("shipping_address",""), request.form.get("state",""),
            request.form.get("notes",""), datetime.now().isoformat(timespec="seconds")))
        c.commit()
        flash("Customer saved.", "success")
        return redirect(url_for("customers"))
    rows = c.execute("SELECT * FROM customers ORDER BY id DESC").fetchall()
    c.close()
    return render_template("customers.html", customers=rows)

@app.route("/admin/invoices")
@login_required
def invoices():
    c = db()
    rows = c.execute("""SELECT i.*, c.company_name FROM invoices i JOIN customers c ON c.id=i.customer_id
                        ORDER BY i.id DESC""").fetchall()
    c.close()
    return render_template("invoices.html", invoices=rows)

@app.route("/admin/invoices/new", methods=["GET","POST"])
@login_required
def new_invoice():
    c = db()
    customers = c.execute("SELECT * FROM customers ORDER BY company_name").fetchall()
    if request.method == "POST":
        customer_id = int(request.form["customer_id"])
        s = settings()
        now = datetime.now()
        prefix = s.get("invoice_prefix","INV")
        invoice_no = f"{prefix}-{now.year}-{now.strftime('%m%d%H%M%S')}"
        descriptions = request.form.getlist("description[]")
        qtys = request.form.getlist("qty[]")
        rates = request.form.getlist("rate[]")
        items = []
        subtotal = 0
        for d,q,r in zip(descriptions, qtys, rates):
            if not d.strip(): continue
            amount = float(q or 0) * float(r or 0)
            subtotal += amount
            items.append((d.strip(), float(q or 0), float(r or 0), amount))
        cgst = float(request.form.get("cgst","0") or 0)
        sgst = float(request.form.get("sgst","0") or 0)
        igst = float(request.form.get("igst","0") or 0)
        total = subtotal + cgst + sgst + igst
        signed_at = now.strftime("%d-%m-%Y %I:%M:%S %p")
        cur = c.execute("""INSERT INTO invoices(invoice_no,customer_id,invoice_date,subtotal,cgst,sgst,igst,total,status,signed_at,created_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                  (invoice_no, customer_id, now.strftime("%Y-%m-%d"), subtotal,cgst,sgst,igst,total,
                   request.form.get("status","Pending"),signed_at,now.isoformat(timespec="seconds")))
        iid = cur.lastrowid
        for d,q,r,a in items:
            c.execute("INSERT INTO invoice_items(invoice_id,description,qty,rate,amount) VALUES(?,?,?,?,?)",(iid,d,q,r,a))
        c.commit()
        c.close()
        try:
            pdf = create_invoice_pdf(iid)
            c = db()
            c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (pdf, iid))
            c.commit(); c.close()
            flash(f"Invoice {invoice_no} created and PDF generated successfully.", "success")
        except Exception as e:
            flash(f"Invoice saved, but PDF generation failed: {e}", "error")
        return redirect(url_for("invoice_detail", iid=iid))
    c.close()
    return render_template("invoice_new.html", customers=customers)

def _safe(text):
    return escape(str(text or ""))

def fit_pdf_image(path, max_w, max_h):
    reader = ImageReader(path)
    iw, ih = reader.getSize()
    if not iw or not ih:
        return Image(path, width=max_w, height=max_h)
    scale = min(max_w / float(iw), max_h / float(ih))
    return Image(path, width=iw * scale, height=ih * scale)

def create_invoice_pdf(iid):
    c = db()
    inv = c.execute("""SELECT i.*, c.company_name,c.contact_person,c.mobile,c.email,c.gstin,c.billing_address
                       FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.id=?""", (iid,)).fetchone()
    items = c.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (iid,)).fetchall()
    c.close()
    if not inv:
        raise ValueError("Invoice not found")

    s = settings()
    path = os.path.join(INVOICE_DIR, f"{inv['invoice_no']}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=14*mm, leftMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    styles = getSampleStyleSheet()
    title = ParagraphStyle("title", parent=styles["Title"], alignment=TA_RIGHT, fontName=PDF_FONT_BOLD, fontSize=18, leading=22)
    small = ParagraphStyle("small", parent=styles["Normal"], fontName=PDF_FONT, fontSize=8, leading=10)
    normal = ParagraphStyle("normal", parent=styles["Normal"], fontName=PDF_FONT, fontSize=9, leading=12)
    story = []

    # Always use the official PNG logo. This avoids the old black/incorrect logo reference.
    logo_name = s.get("signature_image") or "logo.png"
    logo = os.path.join(UPLOADS, logo_name)
    if not os.path.exists(logo):
        logo = os.path.join(BASE, "static", "logo.png")
    if os.path.exists(logo):
        img = fit_pdf_image(logo, 48*mm, 25*mm)
        img.hAlign = "LEFT"
        story.append(img)

    story.append(Paragraph(
        f"<b>{_safe(s.get('company_name','PC SERVICES'))}</b><br/>"
        f"{_safe(s.get('company_address',''))}<br/>"
        f"Phone: {_safe(s.get('company_phone',''))} | Email: {_safe(s.get('company_email',''))}",
        normal))
    story.append(Spacer(1, 5*mm))
    story.append(Paragraph("TAX INVOICE", title))
    story.append(Paragraph(
        f"<b>Invoice No:</b> {_safe(inv['invoice_no'])} &nbsp;&nbsp; "
        f"<b>Date:</b> {_safe(inv['invoice_date'])}", small))
    story.append(Spacer(1, 4*mm))
    story.append(Paragraph(
        f"<b>Bill To:</b> {_safe(inv['company_name'])}<br/>"
        f"{_safe(inv['billing_address'] or '')}<br/>"
        f"GSTIN: {_safe(inv['gstin'] or 'N/A')}", normal))

    data = [["#", "Description", "Qty", "Rate", "Amount"]]
    for n, it in enumerate(items, 1):
        data.append([
            str(n), str(it["description"] or ""), f"{it['qty']:g}",
            f"Rs. {it['rate']:,.2f}", f"Rs. {it['amount']:,.2f}"
        ])
    data += [
        ["", "", "", "Subtotal", f"Rs. {inv['subtotal']:,.2f}"],
        ["", "", "", "CGST", f"Rs. {inv['cgst']:,.2f}"],
        ["", "", "", "SGST", f"Rs. {inv['sgst']:,.2f}"],
        ["", "", "", "IGST", f"Rs. {inv['igst']:,.2f}"],
        ["", "", "", "Grand Total", f"Rs. {inv['total']:,.2f}"]
    ]
    t = Table(data, colWidths=[10*mm, 88*mm, 18*mm, 30*mm, 35*mm], repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#087ff5")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("GRID", (0,0), (-1,-1), 0.35, colors.HexColor("#d9e3ef")),
        ("ALIGN", (2,1), (-1,-1), "RIGHT"),
        ("FONTNAME", (0,0), (-1,0), PDF_FONT_BOLD),
        ("FONTNAME", (0,1), (-1,-1), PDF_FONT),
        ("FONTNAME", (-2,-5), (-1,-1), PDF_FONT_BOLD),
        ("BACKGROUND", (-2,-1), (-1,-1), colors.HexColor("#eef6ff")),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("FONTSIZE", (0,0), (-1,-1), 8)
    ]))
    story += [Spacer(1, 5*mm), t, Spacer(1, 12*mm)]

    story.append(Paragraph("<b>For PC SERVICES</b>", normal))
    # Use the configured signature image; default is the official PC Services logo.
    sig_name = s.get("signature_image") or "logo.png"
    sig = os.path.join(UPLOADS, sig_name)
    if not os.path.exists(sig):
        sig = os.path.join(BASE, "static", "logo.png")
    if os.path.exists(sig):
        story.append(fit_pdf_image(sig, 42*mm, 20*mm))
    else:
        story.append(Spacer(1, 16*mm))
    story.append(Paragraph(
        "<b>Authorized Signatory</b><br/>Computer generated invoice<br/>Date &amp; Time: "
        + _safe(inv["signed_at"]), small))
    story.append(Spacer(1, 5*mm))
    story.append(Paragraph(
        "This invoice was generated electronically by the PC SERVICES Invoice System.", small))
    doc.build(story)
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        raise RuntimeError("PDF file was not created")
    return path

@app.route("/admin/invoices/<int:iid>")
@login_required
def invoice_detail(iid):
    c=db()
    inv=c.execute("""SELECT i.*,c.company_name,c.email,c.mobile FROM invoices i JOIN customers c ON c.id=i.customer_id
                     WHERE i.id=?""",(iid,)).fetchone()
    c.close()
    return render_template("invoice_detail.html", inv=inv)

@app.route("/admin/invoices/<int:iid>/pdf")
@login_required
def invoice_pdf(iid):
    c=db(); inv=c.execute("SELECT * FROM invoices WHERE id=?",(iid,)).fetchone(); c.close()
    if not inv: return "Invoice not found",404
    path = inv["pdf_path"]
    if not path or not os.path.exists(path):
        path = create_invoice_pdf(iid)
        c = db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (path, iid)); c.commit(); c.close()
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="application/pdf")

@app.route("/admin/invoices/<int:iid>/email", methods=["GET","POST"])
@login_required
def email_invoice(iid):
    c=db()
    inv=c.execute("""SELECT i.*,c.company_name,c.email FROM invoices i JOIN customers c ON c.id=i.customer_id
                     WHERE i.id=?""",(iid,)).fetchone()
    c.close()
    s=settings()
    if request.method=="POST":
        to=request.form.get("to","").strip()
        subject=request.form.get("subject","")
        body=request.form.get("body","")
        if not to:
            flash("Customer email is required.","error")
            return redirect(url_for("email_invoice",iid=iid))
        if not s.get("smtp_host") or not s.get("smtp_password"):
            flash("SMTP is not configured yet. Go to Settings and enter your GoDaddy SMTP details.","error")
            return redirect(url_for("email_invoice",iid=iid))
        try:
            msg=EmailMessage()
            msg["From"]=s.get("smtp_user") or "Ranveer@pcservicess.com"
            msg["To"]=to
            msg["Subject"]=subject
            msg.set_content(body + "\n\n" + s.get("email_signature",""))
            path=inv["pdf_path"] or create_invoice_pdf(iid)
            with open(path,"rb") as f:
                msg.add_attachment(f.read(), maintype="application", subtype="pdf", filename=os.path.basename(path))
            port=int(s.get("smtp_port","587"))
            if s.get("smtp_security")=="SSL":
                with smtplib.SMTP_SSL(s["smtp_host"],port,timeout=30) as server:
                    server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
            else:
                with smtplib.SMTP(s["smtp_host"],port,timeout=30) as server:
                    server.ehlo()
                    server.starttls(); server.ehlo()
                    server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
            flash("Invoice email sent with PDF attachment.","success")
        except Exception as e:
            flash("Email failed: "+str(e),"error")
        return redirect(url_for("invoice_detail",iid=iid))
    subject=s["email_subject"].format(invoice_no=inv["invoice_no"])
    body=s["email_body"].format(customer=inv["company_name"],invoice_no=inv["invoice_no"])
    return render_template("email_invoice.html", inv=inv, subject=subject, body=body, signature=s.get("email_signature",""))

@app.route("/admin/users", methods=["GET", "POST"])
@login_required
def user_setup():
    c = db()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "customer")
        customer_id = request.form.get("customer_id") or None
        full_name = request.form.get("full_name", "").strip()
        if not username or not password:
            flash("Username and password are required.", "error")
        elif role == "customer" and not customer_id:
            flash("Please select a customer for a customer login.", "error")
        else:
            try:
                c.execute("INSERT INTO users(username,password_hash,role,customer_id,full_name,active,created_at) VALUES(?,?,?,?,?,?,?)",
                          (username, generate_password_hash(password), role, customer_id if role == "customer" else None,
                           full_name, 1, datetime.now().isoformat(timespec="seconds")))
                c.commit()
                flash("User login created successfully.", "success")
            except sqlite3.IntegrityError:
                flash("Username already exists. Please use another username.", "error")
        c.close()
        return redirect(url_for("user_setup"))
    users = c.execute("""SELECT u.*, c.company_name FROM users u LEFT JOIN customers c ON c.id=u.customer_id ORDER BY u.id DESC""").fetchall()
    customers_list = c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall()
    c.close()
    return render_template("users.html", users=users, customers=customers_list)

@app.route("/admin/users/<int:uid>/toggle", methods=["POST"])
@login_required
def toggle_user(uid):
    c = db()
    user = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not user:
        c.close(); return "User not found", 404
    if user["username"] == "admin" and user["role"] == "admin":
        flash("The default admin account cannot be disabled from this page.", "error")
    else:
        c.execute("UPDATE users SET active=? WHERE id=?", (0 if user["active"] else 1, uid))
        c.commit()
        flash("User status updated.", "success")
    c.close()
    return redirect(url_for("user_setup"))

@app.route("/admin/users/<int:uid>/password", methods=["POST"])
@login_required
def change_user_password(uid):
    password = request.form.get("password", "")
    if len(password) < 6:
        flash("Password must be at least 6 characters.", "error")
        return redirect(url_for("user_setup"))
    c = db()
    c.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(password), uid))
    c.commit(); c.close()
    flash("Password updated successfully.", "success")
    return redirect(url_for("user_setup"))

@app.route("/customer")
@customer_required
def customer_dashboard():
    c = db()
    customer = c.execute("SELECT * FROM customers WHERE id=?", (session["customer_id"],)).fetchone()
    invoices = c.execute("SELECT * FROM invoices WHERE customer_id=? ORDER BY id DESC", (session["customer_id"],)).fetchall()
    total = c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices WHERE customer_id=?", (session["customer_id"],)).fetchone()["n"]
    c.close()
    return render_template("customer_dashboard.html", customer=customer, invoices=invoices, total=total)

@app.route("/customer/invoices/<int:iid>")
@customer_required
def customer_invoice_detail(iid):
    c = db()
    inv = c.execute("""SELECT i.*, c.company_name,c.contact_person,c.mobile,c.email,c.gstin,c.billing_address
                       FROM invoices i JOIN customers c ON c.id=i.customer_id
                       WHERE i.id=? AND i.customer_id=?""", (iid, session["customer_id"])).fetchone()
    items = c.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (iid,)).fetchall() if inv else []
    c.close()
    if not inv: return "Invoice not found", 404
    return render_template("customer_invoice_detail.html", inv=inv, items=items)

@app.route("/customer/invoices/<int:iid>/pdf")
@customer_required
def customer_invoice_pdf(iid):
    c = db()
    inv = c.execute("SELECT * FROM invoices WHERE id=? AND customer_id=?", (iid, session["customer_id"])).fetchone()
    c.close()
    if not inv: return "Invoice not found", 404
    path = inv["pdf_path"]
    if not path or not os.path.exists(path):
        path = create_invoice_pdf(iid)
        c = db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (path, iid)); c.commit(); c.close()
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="application/pdf")

@app.route("/admin/settings", methods=["GET","POST"])
@login_required
def admin_settings():
    if request.method=="POST":
        for k in ["company_name","company_email","company_phone","company_address","gstin","invoice_prefix",
                  "email_signature","email_subject","email_body","smtp_host","smtp_port","smtp_user","smtp_password","smtp_security"]:
            set_setting(k,request.form.get(k,""))
        f=request.files.get("signature")
        if f and f.filename:
            ext=os.path.splitext(f.filename)[1].lower()
            if ext in [".png",".jpg",".jpeg"]:
                name="signature"+ext
                f.save(os.path.join(UPLOADS,name))
                set_setting("signature_image",name)
        flash("Settings saved.","success")
        return redirect(url_for("admin_settings"))
    return render_template("settings.html", s=settings())

@app.route("/admin/settings/test-email", methods=["POST"])
@login_required
def test_email():
    s=settings()
    try:
        if not s.get("smtp_host") or not s.get("smtp_password"):
            raise ValueError("SMTP host/password missing")
        msg=EmailMessage()
        msg["From"]=s["smtp_user"]; msg["To"]=s["smtp_user"]; msg["Subject"]="PC SERVICES SMTP Test"
        msg.set_content("SMTP connection test successful.")
        port=int(s.get("smtp_port","587"))
        if s.get("smtp_security")=="SSL":
            with smtplib.SMTP_SSL(s["smtp_host"],port,timeout=30) as server:
                server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
        else:
            with smtplib.SMTP(s["smtp_host"],port,timeout=30) as server:
                server.starttls(); server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
        flash("Test email sent successfully.","success")
    except Exception as e:
        flash("SMTP test failed: "+str(e),"error")
    return redirect(url_for("admin_settings"))

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=True)
