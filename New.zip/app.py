
import os, sqlite3, secrets, base64, hashlib, shutil, zipfile, threading, time, json
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.lib.units import mm
import smtplib
from email.message import EmailMessage
from xml.sax.saxutils import escape

BASE = os.path.dirname(os.path.abspath(__file__))
INSTANCE_DIR = os.path.join(BASE, "instance")
os.makedirs(INSTANCE_DIR, exist_ok=True)
DB = os.path.join(BASE, "pc_services.db")
UPLOADS = os.path.join(BASE, "static", "uploads")
INVOICE_DIR = os.path.join(BASE, "invoices")
QUOTE_DIR = os.path.join(BASE, "quotes")
SCHEMA_VERSION = "3"

def load_app_secret():
    env_secret = os.environ.get("SECRET_KEY")
    if env_secret:
        return env_secret
    key_path = os.path.join(INSTANCE_DIR, "secret.key")
    if os.path.exists(key_path):
        with open(key_path, "r", encoding="utf-8") as handle:
            return handle.read().strip()
    value = secrets.token_urlsafe(48)
    with open(key_path, "w", encoding="utf-8") as handle:
        handle.write(value)
    try:
        os.chmod(key_path, 0o600)
    except OSError:
        pass
    return value

try:
    from cryptography.fernet import Fernet, InvalidToken
    CRYPTO_AVAILABLE = True
except ImportError:
    Fernet = None
    InvalidToken = Exception
    CRYPTO_AVAILABLE = False

def _fernet():
    key_material = os.environ.get("SECRET_KEY") or load_app_secret()
    key = base64.urlsafe_b64encode(hashlib.sha256(key_material.encode("utf-8")).digest())
    return Fernet(key) if CRYPTO_AVAILABLE else None

def encrypt_secret(value):
    f = _fernet()
    return f.encrypt(value.encode("utf-8")).decode("ascii") if f else value

def decrypt_secret(value):
    if not value:
        return ""
    f = _fernet()
    if not f:
        return value
    try:
        return f.decrypt(value.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError, UnicodeError):
        # Legacy plaintext credentials are migrated when saved in Settings.
        return value
FONT_REG = "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf"
if os.path.exists(FONT_REG):
    pdfmetrics.registerFont(TTFont("NotoSans", FONT_REG))
if os.path.exists(FONT_BOLD):
    pdfmetrics.registerFont(TTFont("NotoSans-Bold", FONT_BOLD))
PDF_FONT = "NotoSans" if os.path.exists(FONT_REG) else "Helvetica"
PDF_FONT_BOLD = "NotoSans-Bold" if os.path.exists(FONT_BOLD) else "Helvetica-Bold"
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(INVOICE_DIR, exist_ok=True)
os.makedirs(QUOTE_DIR, exist_ok=True)

BACKUP_DIR = os.environ.get("PC_SERVICES_BACKUP_DIR", os.path.join(BASE, "backups"))
os.makedirs(BACKUP_DIR, exist_ok=True)
_backup_lock = threading.Lock()

def create_backup(reason="daily"):
    """Create a consistent SQLite snapshot and preserve a dated backup forever."""
    if not os.path.exists(DB) or os.path.getsize(DB) == 0:
        raise RuntimeError("Main database does not exist yet; no backup was created.")
    with _backup_lock:
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        target = os.path.join(BACKUP_DIR, f"pc_services_{reason}_{stamp}.zip")
        temp_db = os.path.join(BACKUP_DIR, f".snapshot_{stamp}.db")
        src = sqlite3.connect(DB, timeout=30)
        dst = sqlite3.connect(temp_db)
        try:
            src.backup(dst)
            dst.commit()
        finally:
            dst.close(); src.close()
        try:
            with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.write(temp_db, "pc_services.db")
                for folder in ("static/uploads", "invoices", "quotes"):
                    full = os.path.join(BASE, folder)
                    if os.path.isdir(full):
                        for root, dirs, files in os.walk(full):
                            dirs[:] = [d for d in dirs if d not in {"__pycache__", ".git"}]
                            for name in files:
                                path = os.path.join(root, name)
                                zf.write(path, os.path.relpath(path, BASE))
                zf.writestr("BACKUP_INFO.txt", f"PC Services backup\nCreated: {datetime.now().isoformat(timespec='seconds')}\nReason: {reason}\nDatabase snapshot: consistent SQLite backup\n")
        finally:
            try: os.remove(temp_db)
            except OSError: pass
        return target

def _daily_backup_worker():
    """Daily backup loop. Backups are never auto-pruned or overwritten."""
    while True:
        try:
            now = datetime.now()
            if now.hour == 2:
                daily_prefix = "pc_services_daily_" + now.strftime("%Y-%m-%d")
                if not any(n.startswith(daily_prefix) for n in os.listdir(BACKUP_DIR)):
                    create_backup("daily")
        except Exception as exc:
            try:
                with open(os.path.join(BACKUP_DIR, "backup_errors.log"), "a", encoding="utf-8") as log:
                    log.write(f"{datetime.now().isoformat(timespec='seconds')} {type(exc).__name__}: {exc}\n")
            except OSError:
                pass
        time.sleep(60)

app = Flask(__name__)
app.secret_key = load_app_secret()
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
app.config["PERMANENT_SESSION_LIFETIME"] = 300

@app.before_request
def enforce_session_security():
    """Enforce 5-minute inactivity timeout and one active login per user."""
    uid = session.get("user_id")
    if not uid or request.endpoint in ("login", "home", "static"):
        return None
    now = time.time()
    last = session.get("last_activity_ts", now)
    if now - float(last) >= 300:
        session.clear()
        flash("You were logged out after 5 minutes of inactivity.", "error")
        return redirect(url_for("login"))
    token = session.get("session_token")
    try:
        conn = db()
        row = conn.execute("SELECT active, active_session_token FROM users WHERE id=?", (uid,)).fetchone()
        conn.close()
    except sqlite3.Error:
        row = None
    if not row or not row["active"] or not token or row["active_session_token"] != token:
        session.clear()
        flash("Your session ended because this account logged in elsewhere or was disabled.", "error")
        return redirect(url_for("login"))
    session["last_activity_ts"] = now
    session.permanent = True
    return None

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    # One-time automatic safety backup before the first incremental schema migration.
    if os.path.exists(DB) and os.path.getsize(DB) > 0:
        needs_backup = True
        try:
            check = sqlite3.connect(DB)
            has_settings = check.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='settings'").fetchone()
            if has_settings:
                marker = check.execute("SELECT value FROM settings WHERE key='schema_version'").fetchone()
                if marker and marker[0] == SCHEMA_VERSION:
                    needs_backup = False
            check.close()
        except sqlite3.Error:
            needs_backup = True
        if needs_backup:
            backup_dir=os.path.join(BASE,"backups"); os.makedirs(backup_dir,exist_ok=True)
            stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path=os.path.join(backup_dir,f"pc_services_before_upgrade_{stamp}.db")
            shutil.copy2(DB,backup_path)
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT
    );
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_name TEXT NOT NULL, contact_person TEXT, mobile TEXT, email TEXT,
        gstin TEXT, billing_address TEXT, shipping_address TEXT, state TEXT,
        notes TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_no TEXT UNIQUE NOT NULL, customer_id INTEGER NOT NULL,
        invoice_date TEXT NOT NULL, subtotal REAL DEFAULT 0,
        cgst REAL DEFAULT 0, sgst REAL DEFAULT 0, igst REAL DEFAULT 0,
        cgst_rate REAL DEFAULT 0, sgst_rate REAL DEFAULT 0, igst_rate REAL DEFAULT 0,
        total REAL DEFAULT 0, status TEXT DEFAULT 'Pending',
        pdf_path TEXT, signed_at TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'customer',
        customer_id INTEGER,
        full_name TEXT,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        active_session_token TEXT,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_name TEXT NOT NULL, category TEXT, brand TEXT, model TEXT, part_no TEXT,
        serial_no TEXT, purchase_price REAL DEFAULT 0, selling_price REAL DEFAULT 0,
        gst_rate REAL DEFAULT 0, stock_qty REAL DEFAULT 0, warranty TEXT, warranty_until TEXT, vendor TEXT,
        active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, min_stock REAL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL, description TEXT NOT NULL,
        qty REAL DEFAULT 1, rate REAL DEFAULT 0, amount REAL DEFAULT 0,
        product_id INTEGER,
        FOREIGN KEY(invoice_id) REFERENCES invoices(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    """)
    # Backward-compatible security and stock-threshold migrations.
    user_cols = {r[1] for r in c.execute("PRAGMA table_info(users)").fetchall()}
    if "active_session_token" not in user_cols:
        c.execute("ALTER TABLE users ADD COLUMN active_session_token TEXT")
    product_cols = {r[1] for r in c.execute("PRAGMA table_info(products)").fetchall()}
    if "min_stock" not in product_cols:
        c.execute("ALTER TABLE products ADD COLUMN min_stock REAL DEFAULT 0")
    # Backward-compatible migration for databases created by older versions.
    cols = {r[1] for r in c.execute("PRAGMA table_info(invoices)").fetchall()}
    for col in ("cgst_rate", "sgst_rate", "igst_rate"):
        if col not in cols:
            c.execute(f"ALTER TABLE invoices ADD COLUMN {col} REAL DEFAULT 0")
    if "po_number" not in cols:
        c.execute("ALTER TABLE invoices ADD COLUMN po_number TEXT")
    if "po_date" not in cols:
        c.execute("ALTER TABLE invoices ADD COLUMN po_date TEXT")
    product_cols = {r[1] for r in c.execute("PRAGMA table_info(products)").fetchall()}
    if "warranty_until" not in product_cols:
        c.execute("ALTER TABLE products ADD COLUMN warranty_until TEXT")
    item_cols = {r[1] for r in c.execute("PRAGMA table_info(invoice_items)").fetchall()}
    if "product_id" not in item_cols:
        c.execute("ALTER TABLE invoice_items ADD COLUMN product_id INTEGER")

    # Incremental business modules. All additions are non-destructive.
    c.executescript("""
    CREATE TABLE IF NOT EXISTS user_permissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, module TEXT NOT NULL, UNIQUE(user_id,module),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS vendors (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, contact_person TEXT, mobile TEXT, email TEXT, gstin TEXT, address TEXT, notes TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'staff', mobile TEXT, email TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS service_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS rental_equipment (
      id INTEGER PRIMARY KEY AUTOINCREMENT, equipment_name TEXT NOT NULL, serial_no TEXT, model TEXT, monthly_rate REAL DEFAULT 0, status TEXT DEFAULT 'Available', notes TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS stock_movements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, movement_type TEXT NOT NULL, quantity_change REAL NOT NULL, balance_after REAL NOT NULL, reference_type TEXT, reference_id INTEGER, notes TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(product_id) REFERENCES products(id)
    );
    CREATE TABLE IF NOT EXISTS purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_no TEXT UNIQUE NOT NULL, vendor_id INTEGER, purchase_date TEXT NOT NULL, product_id INTEGER NOT NULL, qty REAL NOT NULL, unit_cost REAL NOT NULL, amount REAL NOT NULL, notes TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(vendor_id) REFERENCES vendors(id), FOREIGN KEY(product_id) REFERENCES products(id)
    );
    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, amount REAL NOT NULL, payment_date TEXT NOT NULL, method TEXT, reference TEXT, notes TEXT, created_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY(invoice_id) REFERENCES invoices(id)
    );
    CREATE TABLE IF NOT EXISTS quotes (
      id INTEGER PRIMARY KEY AUTOINCREMENT, quote_no TEXT UNIQUE NOT NULL, customer_id INTEGER NOT NULL, quote_date TEXT NOT NULL, valid_until TEXT, description TEXT, taxable_amount REAL DEFAULT 0, gst_rate REAL DEFAULT 0, gst_type TEXT DEFAULT 'CGST+SGST', gst_amount REAL DEFAULT 0, total REAL DEFAULT 0, status TEXT DEFAULT 'Draft', created_at TEXT NOT NULL,
      FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    CREATE TABLE IF NOT EXISTS quote_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT, quote_id INTEGER NOT NULL, description TEXT NOT NULL,
      qty REAL NOT NULL DEFAULT 1, rate REAL NOT NULL DEFAULT 0, gst_rate REAL NOT NULL DEFAULT 0,
      amount REAL NOT NULL DEFAULT 0, FOREIGN KEY(quote_id) REFERENCES quotes(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS rentals (
      id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, equipment_id INTEGER, description TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT, monthly_rent REAL DEFAULT 0, gst_rate REAL DEFAULT 0, gst_type TEXT DEFAULT 'CGST+SGST', billing_day INTEGER DEFAULT 1, status TEXT DEFAULT 'Active', last_billed_month TEXT, notes TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(customer_id) REFERENCES customers(id), FOREIGN KEY(equipment_id) REFERENCES rental_equipment(id)
    );
    CREATE TABLE IF NOT EXISTS rental_bills (
      id INTEGER PRIMARY KEY AUTOINCREMENT, rental_id INTEGER NOT NULL, billing_month TEXT NOT NULL, amount REAL NOT NULL, gst_rate REAL DEFAULT 0, gst_type TEXT DEFAULT 'CGST+SGST', status TEXT DEFAULT 'Draft', invoice_id INTEGER, created_at TEXT NOT NULL, UNIQUE(rental_id,billing_month),
      FOREIGN KEY(rental_id) REFERENCES rentals(id), FOREIGN KEY(invoice_id) REFERENCES invoices(id)
    );
    CREATE TABLE IF NOT EXISTS service_jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, job_no TEXT UNIQUE NOT NULL, customer_id INTEGER NOT NULL, category_id INTEGER, assigned_employee_id INTEGER, equipment TEXT, serial_no TEXT, complaint TEXT NOT NULL, parts_cost REAL DEFAULT 0, labour_cost REAL DEFAULT 0, status TEXT DEFAULT 'Open', warranty_until TEXT, opened_at TEXT NOT NULL, closed_at TEXT, notes TEXT,
      FOREIGN KEY(customer_id) REFERENCES customers(id), FOREIGN KEY(category_id) REFERENCES service_categories(id), FOREIGN KEY(assigned_employee_id) REFERENCES employees(id)
    );
    CREATE TABLE IF NOT EXISTS quote_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT, service TEXT, message TEXT, status TEXT DEFAULT 'New', created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS email_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT, subject TEXT, kind TEXT, status TEXT, error TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT, entity_type TEXT NOT NULL, entity_id INTEGER, action TEXT NOT NULL, before_json TEXT, after_json TEXT, actor TEXT, created_at TEXT NOT NULL
    );
    """)
    rental_cols = {r[1] for r in c.execute("PRAGMA table_info(rentals)").fetchall()}
    if "gst_rate" not in rental_cols:
        c.execute("ALTER TABLE rentals ADD COLUMN gst_rate REAL DEFAULT 0")
    if "gst_type" not in rental_cols:
        c.execute("ALTER TABLE rentals ADD COLUMN gst_type TEXT DEFAULT 'CGST+SGST'")
    item_cols = {r[1] for r in c.execute("PRAGMA table_info(invoice_items)").fetchall()}
    if "cost_at_sale" not in item_cols:
        c.execute("ALTER TABLE invoice_items ADD COLUMN cost_at_sale REAL")
    invoice_cols = {r[1] for r in c.execute("PRAGMA table_info(invoices)").fetchall()}
    if "quote_id" not in invoice_cols:
        c.execute("ALTER TABLE invoices ADD COLUMN quote_id INTEGER")
    quote_cols = {r[1] for r in c.execute("PRAGMA table_info(quotes)").fetchall()}
    if "gst_type" not in quote_cols:
        c.execute("ALTER TABLE quotes ADD COLUMN gst_type TEXT DEFAULT 'CGST+SGST'")
    c.execute("CREATE INDEX IF NOT EXISTS idx_payments_invoice ON payments(invoice_id, active)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_quote_requests_status ON quote_requests(status)")

    defaults = {
        "company_name": "PC SERVICES",
        "company_email": "Ranveer@pcservicess.com",
        "quote_admin_email": "Ranveer@pcservicess.com",
        "company_phone": "+91 9977607027",
        "company_address": "EM-325 B Indus Town II Pithampur 454775, Madhya Pradesh, India",
        "gstin": "",
        "invoice_prefix": "INV",
        "email_signature": "Regards,\nRanveer\nPC SERVICES\nRanveer@pcservicess.com",
        "email_subject": "Invoice {invoice_no} from PC SERVICES",
        "email_body": "Dear {customer},\n\nPlease find attached your invoice {invoice_no}.\n\nThank you for your business.",
        "smtp_host": "",
        "smtp_port": "587",
        "smtp_user": "Ranveer@pcservicess.com",
        "smtp_password": "",
        "smtp_security": "STARTTLS",
        "signature_image": "logo.png",
    }
    # Create the initial admin account if the users table is empty.
    existing_admin = c.execute("SELECT id FROM users WHERE role='admin' LIMIT 1").fetchone()
    if not existing_admin:
        c.execute("INSERT OR IGNORE INTO users(username,password_hash,role,full_name,active,created_at) VALUES(?,?,?,?,?,?)",
                  ("admin", generate_password_hash("admin123"), "admin", "Administrator", 1, datetime.now().isoformat(timespec="seconds")))
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    legacy_pw = c.execute("SELECT value FROM settings WHERE key='smtp_password'").fetchone()
    encrypted_pw = c.execute("SELECT value FROM settings WHERE key='smtp_password_enc'").fetchone()
    if legacy_pw and legacy_pw["value"] and not encrypted_pw:
        c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('smtp_password_enc',?)", (encrypt_secret(legacy_pw["value"]),))
        c.execute("DELETE FROM settings WHERE key='smtp_password'")
    c.execute("INSERT INTO settings(key,value) VALUES('schema_version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(SCHEMA_VERSION,))
    c.commit()
    c.close()

def settings():
    c = db()
    rows = c.execute("SELECT key,value FROM settings").fetchall()
    c.close()
    values = {r["key"]: r["value"] for r in rows}
    encrypted = values.get("smtp_password_enc", "")
    if encrypted:
        values["smtp_password"] = decrypt_secret(encrypted)
    return values

def set_setting(k, v):
    c = db()
    c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
    c.commit(); c.close()

def _module_for_path(path):
    mapping=[("/admin/rentals/billing","admin_only"),("/admin/reminders","admin_only"),("/admin/masters/products","product_master"),("/admin/masters/vendors","vendors"),("/admin/masters/employees","employees"),
      ("/admin/masters/service-categories","service_categories"),("/admin/masters/rental-equipment","rental_equipment"),
      ("/admin/quote-requests","quote_requests"),("/admin/email-logs","admin_only"),("/admin/audit-log","admin_only"),
      ("/admin/users","admin_only"),("/admin/settings","admin_only"),("/admin/payments","payments"),
      ("/admin/purchases","purchases"),("/admin/stock-movements","stock_movements"),("/admin/products","products"),("/admin/customers","customers"),
      ("/admin/invoices","invoices"),("/admin/quotes","quotes"),("/admin/rentals","rentals"),
      ("/admin/service-jobs","service_jobs"),("/admin/reports","reports")]
    for prefix,module in mapping:
        if path==prefix or path.startswith(prefix+"/"):
            return module
    if path=="/admin": return "dashboard"
    return "admin_only"

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        role=session.get("role")
        if role=="admin": return fn(*args, **kwargs)
        if role in ("staff","technician") and session.get("user_id"):
            module=_module_for_path(getattr(request,"path","/admin"))
            if module!="admin_only" and module in session.get("permissions",[]):
                return fn(*args, **kwargs)
            return "Access denied: your account is not authorized for this module.",403
        return redirect(url_for("login"))
    return wrapped

def customer_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if session.get("role") != "customer" or not session.get("customer_id"):
            return redirect(url_for("customer_login"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    init_db()
    return render_template("index.html")

@app.route("/login", methods=["GET","POST"])
@app.route("/admin/login", methods=["GET","POST"])
@app.route("/customer/login", methods=["GET","POST"])
def login():
    """Single login screen for both Admin and Customer users."""
    init_db()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        c = db()
        user = c.execute("SELECT u.*, c.company_name FROM users u LEFT JOIN customers c ON c.id=u.customer_id WHERE u.username=? AND u.active=1", (username,)).fetchone()
        c.close()
        if user and check_password_hash(user["password_hash"], password):
            # New login invalidates every older session for this user.
            token = secrets.token_urlsafe(32)
            c = db()
            c.execute("UPDATE users SET active_session_token=? WHERE id=?", (token, user["id"]))
            c.commit(); c.close()
            # Customer users must always be linked to one valid customer.
            if user["role"] == "customer":
                if not user["customer_id"] or not user["company_name"]:
                    flash("This customer login is not linked to a company. Please contact PC SERVICES.", "error")
                    return render_template("login.html")
                session.clear()
                session["user_id"] = user["id"]
                session["session_token"] = token
                session["last_activity_ts"] = time.time()
                session.permanent = True
                session["role"] = "customer"
                session["customer_id"] = int(user["customer_id"])
                session["username"] = user["username"]
                session["customer_company"] = user["company_name"]
                return redirect(url_for("customer_dashboard"))
            if user["role"] == "admin":
                session.clear()
                session["user_id"] = user["id"]
                session["session_token"] = token
                session["last_activity_ts"] = time.time()
                session.permanent = True
                session["role"] = "admin"
                session["admin"] = True
                session["username"] = user["username"]
                return redirect(url_for("dashboard"))
            if user["role"] in ("staff", "technician"):
                c=db(); perms=c.execute("SELECT module FROM user_permissions WHERE user_id=?",(user["id"],)).fetchall(); c.close()
                session.clear(); session["user_id"]=user["id"]; session["session_token"]=token; session["last_activity_ts"]=time.time(); session.permanent=True; session["role"]=user["role"]
                session["username"]=user["username"]; session["permissions"]=[x["module"] for x in perms]
                return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
@app.route("/admin/logout")
def logout():
    uid = session.get("user_id"); token = session.get("session_token")
    if uid and token:
        c=db(); c.execute("UPDATE users SET active_session_token=NULL WHERE id=? AND active_session_token=?", (uid, token)); c.commit(); c.close()
    session.clear()
    return redirect(url_for("login"))

@app.route("/admin")
@login_required
def dashboard():
    c = db()
    customers = c.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"]
    invoices = c.execute("SELECT COUNT(*) n FROM invoices").fetchone()["n"]
    pending = c.execute("SELECT COALESCE(SUM(CASE WHEN i.status='Paid' AND p.paid IS NULL THEN 0 ELSE MAX(i.total-COALESCE(p.paid,0),0) END),0) n FROM invoices i LEFT JOIN (SELECT invoice_id,SUM(amount) paid FROM payments WHERE active=1 GROUP BY invoice_id) p ON p.invoice_id=i.id").fetchone()["n"]
    sales = c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices WHERE strftime('%Y-%m', invoice_date)=strftime('%Y-%m','now')").fetchone()["n"]
    sales_total = c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices").fetchone()["n"]
    gst_sales = c.execute("SELECT COALESCE(SUM(cgst+sgst+igst),0) n FROM invoices").fetchone()["n"]
    purchases_total = c.execute("SELECT COALESCE(SUM(amount),0) n FROM purchases").fetchone()["n"]
    gross_profit = c.execute("SELECT COALESCE(SUM(ii.amount-COALESCE(ii.cost_at_sale,0)*ii.qty),0) n FROM invoice_items ii JOIN invoices i ON i.id=ii.invoice_id WHERE ii.cost_at_sale IS NOT NULL").fetchone()["n"]
    recent = c.execute("""SELECT i.*, c.company_name FROM invoices i JOIN customers c ON c.id=i.customer_id
                          ORDER BY i.id DESC LIMIT 8""").fetchall()
    c.close()
    return render_template("dashboard.html", customers=customers, invoices=invoices, pending=pending, sales=sales, sales_total=sales_total, recent=recent, gst_sales=gst_sales, purchases_total=purchases_total, gross_profit=gross_profit)

@app.route("/admin/customers", methods=["GET","POST"])
@login_required
def customers():
    c = db()
    if request.method == "POST":
        c.execute("""INSERT INTO customers(company_name,contact_person,mobile,email,gstin,billing_address,
                    shipping_address,state,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)""", (
            request.form["company_name"], request.form.get("contact_person",""),
            request.form.get("mobile",""), request.form.get("email",""),
            request.form.get("gstin",""), request.form.get("billing_address",""),
            request.form.get("shipping_address",""), request.form.get("state",""),
            request.form.get("notes",""), datetime.now().isoformat(timespec="seconds")))
        c.commit()
        flash("Customer saved.", "success")
        return redirect(url_for("customers"))
    search = request.args.get("q", "").strip()
    sql = "SELECT * FROM customers WHERE 1=1"; args=[]
    if search:
        sql += " AND (company_name LIKE ? OR contact_person LIKE ? OR mobile LIKE ? OR email LIKE ? OR gstin LIKE ?)"
        args.extend(["%"+search+"%"]*5)
    rows = c.execute(sql+" ORDER BY id DESC", args).fetchall()
    c.close()
    return render_template("customers.html", customers=rows, search=search)

@app.route("/admin/products", methods=["GET", "POST"])
@login_required
def products():
    if request.method == "POST":
        return redirect(url_for("product_master"))
    c=db(); search=request.args.get("q","").strip(); low=request.args.get("low","")
    sql="SELECT * FROM products WHERE 1=1"; args=[]
    if search:
        sql+=" AND (product_name LIKE ? OR category LIKE ? OR brand LIKE ? OR model LIKE ? OR serial_no LIKE ?)"; args.extend(["%"+search+"%"]*5)
    if low=="1": sql+=" AND stock_qty<=COALESCE(min_stock,0)"
    sql+=" ORDER BY product_name"
    rows=c.execute(sql,args).fetchall(); c.close()
    return render_template("product_list.html",products=rows,search=search,low=low)

@app.route("/admin/masters/products", methods=["GET", "POST"])
@login_required
def product_master():
    c=db()
    if request.method=="POST":
        name=request.form.get("product_name","").strip()
        if not name:
            c.close(); flash("Product name is required.","error"); return redirect(url_for("product_master"))
        try:
            cur=c.execute("INSERT INTO products(product_name,category,brand,model,part_no,serial_no,purchase_price,selling_price,gst_rate,stock_qty,warranty,warranty_until,vendor,active,created_at,min_stock) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(
              name,request.form.get("category","").strip(),request.form.get("brand","").strip(),request.form.get("model","").strip(),request.form.get("part_no","").strip(),request.form.get("serial_no","").strip(),float(request.form.get("purchase_price","0") or 0),float(request.form.get("selling_price","0") or 0),float(request.form.get("gst_rate","0") or 0),float(request.form.get("stock_qty","0") or 0),request.form.get("warranty","").strip(),request.form.get("warranty_until") or None,request.form.get("vendor","").strip(),1,datetime.now().isoformat(timespec="seconds"),float(request.form.get("min_stock","0") or 0)))
            if float(request.form.get("stock_qty","0") or 0)>0:
                c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity_change,balance_after,reference_type,reference_id,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(cur.lastrowid,"Opening Stock",float(request.form.get("stock_qty","0") or 0),float(request.form.get("stock_qty","0") or 0),"product",cur.lastrowid,"Initial stock entered in Product Master",datetime.now().isoformat(timespec="seconds")))
            c.commit(); flash("Product Master record saved successfully.","success")
        except ValueError:
            flash("Price, GST and stock fields must contain valid numbers.","error")
        c.close(); return redirect(url_for("product_master"))
    rows=c.execute("SELECT * FROM products ORDER BY id DESC").fetchall(); c.close()
    return render_template("products.html",products=rows)

@app.route("/admin/products/<int:pid>/stock", methods=["POST"])
@login_required
def adjust_product_stock(pid):
    try:
        qty=float(request.form.get("quantity", "0") or 0)
        if qty <= 0: raise ValueError()
    except ValueError:
        flash("Enter a stock quantity greater than zero.", "error")
        return redirect(url_for("products"))
    c=db(); row=c.execute("SELECT stock_qty FROM products WHERE id=?",(pid,)).fetchone()
    if not row: c.close(); flash("Product not found.","error"); return redirect(url_for("products"))
    balance=float(row["stock_qty"] or 0)+qty
    now=datetime.now().isoformat(timespec="seconds")
    c.execute("UPDATE products SET stock_qty=? WHERE id=?",(balance,pid))
    c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity_change,balance_after,reference_type,reference_id,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,"Stock Increase",qty,balance,"manual",pid,request.form.get("notes","").strip(),now))
    c.commit(); c.close(); flash("Stock quantity increased and movement recorded.","success")
    return redirect(url_for("products"))

@app.route("/admin/products/<int:pid>/price", methods=["POST"])
@login_required
def update_product_price(pid):
    try:
        purchase=float(request.form.get("purchase_price", "0") or 0)
        selling=float(request.form.get("selling_price", "0") or 0)
        if purchase < 0 or selling < 0: raise ValueError()
    except ValueError:
        flash("Prices must be valid non-negative numbers.","error"); return redirect(url_for("products"))
    c=db(); row=c.execute("SELECT purchase_price,selling_price FROM products WHERE id=?",(pid,)).fetchone()
    if not row: c.close(); flash("Product not found.","error"); return redirect(url_for("products"))
    now=datetime.now().isoformat(timespec="seconds")
    before={"purchase_price":row["purchase_price"],"selling_price":row["selling_price"]}
    after={"purchase_price":purchase,"selling_price":selling}
    c.execute("UPDATE products SET purchase_price=?,selling_price=? WHERE id=?",(purchase,selling,pid))
    c.execute("INSERT INTO audit_log(entity_type,entity_id,action,before_json,after_json,actor,created_at) VALUES(?,?,?,?,?,?,?)",("product",pid,"Price Update",json.dumps(before),json.dumps(after),session.get("username","unknown"),now))
    c.commit(); c.close(); flash("Prices updated; change recorded in audit history.","success")
    return redirect(url_for("products"))

@app.route("/admin/masters/products/<int:pid>/toggle", methods=["POST"])
@login_required
def toggle_product(pid):
    c=db(); c.execute("UPDATE products SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=?",(pid,)); c.commit(); c.close()
    flash("Product status updated.","success"); return redirect(url_for("product_master"))

def next_invoice_number(conn, when=None):
    """Create a sequential invoice number for the April–March financial year."""
    when = when or datetime.now()
    fy_start = when.year if when.month >= 4 else when.year - 1
    fy_end = fy_start + 1
    fy_label = f"{fy_start}-{str(fy_end)[-2:]}"
    prefix = f"PCS/{fy_label}/"
    # Query only this financial-year prefix; use the numeric suffix, not row count.
    rows = conn.execute("SELECT invoice_no FROM invoices WHERE invoice_no LIKE ?", (prefix + "%",)).fetchall()
    largest = 0
    for row in rows:
        try:
            suffix = str(row["invoice_no"])[len(prefix):]
            if suffix.isdigit(): largest = max(largest, int(suffix))
        except (TypeError, ValueError):
            continue
    return f"{prefix}{largest + 1:04d}"


@app.route("/admin/invoices")
@login_required
def invoices():
    c = db(); customer_id=request.args.get("customer_id","").strip(); search=request.args.get("q","").strip()
    sql="SELECT i.*, c.company_name FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE 1=1"; args=[]
    if customer_id:
        sql+=" AND i.customer_id=?"; args.append(customer_id)
    if search:
        sql+=" AND (i.invoice_no LIKE ? OR COALESCE(i.po_number,'') LIKE ? OR c.company_name LIKE ?)"; args.extend(["%"+search+"%","%"+search+"%","%"+search+"%"])
    sql+=" ORDER BY i.id DESC"
    rows=c.execute(sql,args).fetchall(); customers_list=c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall(); c.close()
    return render_template("invoices.html", invoices=rows, customers=customers_list, selected_customer=customer_id, search=search)

@app.route("/admin/invoices/new", methods=["GET","POST"])
@login_required
def new_invoice():
    c = db()
    customers = c.execute("SELECT * FROM customers ORDER BY company_name").fetchall()
    products_list = c.execute("SELECT * FROM products WHERE active=1 ORDER BY product_name").fetchall()
    if request.method == "POST":
        customer_id = int(request.form["customer_id"])
        s = settings()
        now = datetime.now()
        invoice_no = next_invoice_number(c, now)
        po_number = request.form.get("po_number", "").strip() or None
        po_date = request.form.get("po_date", "").strip() or None
        descriptions = request.form.getlist("description[]")
        qtys = request.form.getlist("qty[]")
        rates = request.form.getlist("rate[]")
        product_ids = request.form.getlist("product_id[]")
        items = []
        subtotal = 0
        for idx, (d,q,r) in enumerate(zip(descriptions, qtys, rates)):
            if not d.strip(): continue
            quantity=float(q or 0); unit_rate=float(r or 0)
            if quantity<=0 or unit_rate<0:
                c.close(); flash("Each invoice item must have quantity above zero and a non-negative rate.","error"); return redirect(url_for("new_invoice"))
            amount=round(quantity*unit_rate,2); subtotal+=amount
            pid=int(product_ids[idx]) if idx<len(product_ids) and product_ids[idx] else None
            items.append((d.strip(),quantity,unit_rate,amount,pid))
        if not items:
            c.close(); flash("Add at least one invoice item before generating the invoice.","error"); return redirect(url_for("new_invoice"))
        # GST is always calculated from the taxable subtotal using percentages.
        cgst_rate = max(0.0, float(request.form.get("cgst_rate","0") or 0))
        sgst_rate = max(0.0, float(request.form.get("sgst_rate","0") or 0))
        igst_rate = max(0.0, float(request.form.get("igst_rate","0") or 0))
        cgst = round(subtotal * cgst_rate / 100.0, 2)
        sgst = round(subtotal * sgst_rate / 100.0, 2)
        igst = round(subtotal * igst_rate / 100.0, 2)
        total = round(subtotal + cgst + sgst + igst, 2)
        signed_at = now.strftime("%d-%m-%Y %I:%M:%S %p")
        cur = c.execute("""INSERT INTO invoices(invoice_no,customer_id,invoice_date,subtotal,cgst,sgst,igst,cgst_rate,sgst_rate,igst_rate,total,status,signed_at,created_at,po_number,po_date)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (invoice_no, customer_id, now.strftime("%Y-%m-%d"), subtotal,cgst,sgst,igst,cgst_rate,sgst_rate,igst_rate,total,
                   request.form.get("status","Pending"),signed_at,now.isoformat(timespec="seconds"),po_number,po_date))
        iid = cur.lastrowid
        for d,q,r,a,pid in items:
            cost = None
            if pid:
                product = c.execute("SELECT purchase_price,stock_qty FROM products WHERE id=?", (pid,)).fetchone()
                if product:
                    cost = float(product["purchase_price"] or 0)
                    # Negative stock is permitted by the approved policy; record a warning.
                    if float(product["stock_qty"] or 0) < q:
                        flash(f"Stock warning: {d} has only {float(product['stock_qty'] or 0):g} available; sale recorded with negative stock allowed.", "error")
                    c.execute("UPDATE products SET stock_qty=COALESCE(stock_qty,0)-? WHERE id=?", (q, pid))
                    balance=c.execute("SELECT stock_qty FROM products WHERE id=?",(pid,)).fetchone()["stock_qty"]
                    c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity_change,balance_after,reference_type,reference_id,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,"Sale",-q,balance,"invoice",iid,invoice_no,datetime.now().isoformat(timespec="seconds")))
            c.execute("INSERT INTO invoice_items(invoice_id,description,qty,rate,amount,product_id,cost_at_sale) VALUES(?,?,?,?,?,?,?)",(iid,d,q,r,a,pid,cost))
        c.commit()
        c.close()
        try:
            pdf = create_invoice_pdf(iid)
            c = db()
            c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (pdf, iid))
            c.commit(); c.close()
            flash(f"Invoice {invoice_no} created and PDF generated successfully.", "success")
        except Exception as e:
            flash(f"Invoice saved, but PDF generation failed: {e}", "error")
        return redirect(url_for("invoice_detail", iid=iid))
    c.close()
    return render_template("invoice_new.html", customers=customers, products=products_list)

def _safe(text):
    return escape(str(text or ""))

def fit_pdf_image(path, max_w, max_h):
    reader = ImageReader(path)
    iw, ih = reader.getSize()
    if not iw or not ih:
        return Image(path, width=max_w, height=max_h)
    scale = min(max_w / float(iw), max_h / float(ih))
    return Image(path, width=iw * scale, height=ih * scale)

def create_invoice_pdf(iid):
    """Build portrait A4 GST invoice following the customer's uploaded reference layout."""
    c = db()
    inv = c.execute("""SELECT i.*, c.company_name,c.contact_person,c.mobile,c.email,c.gstin,c.billing_address,c.shipping_address,c.state
                       FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.id=?""", (iid,)).fetchone()
    items = c.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (iid,)).fetchall()
    c.close()
    if not inv: raise ValueError("Invoice not found")
    s = settings()
    safe_invoice_name = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(inv["invoice_no"]))
    path = os.path.join(INVOICE_DIR, f"{safe_invoice_name}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=13*mm, leftMargin=13*mm, topMargin=10*mm, bottomMargin=12*mm)
    styles = getSampleStyleSheet()
    body = ParagraphStyle("InvoiceBody", parent=styles["Normal"], fontName=PDF_FONT, fontSize=8.4, leading=11)
    tiny = ParagraphStyle("InvoiceTiny", parent=body, fontSize=7.3, leading=9)
    right = ParagraphStyle("InvoiceRight", parent=body, alignment=TA_RIGHT)
    heading = ParagraphStyle("InvoiceHeading", parent=body, fontName=PDF_FONT_BOLD, fontSize=18, leading=21, alignment=TA_RIGHT)
    label = ParagraphStyle("InvoiceLabel", parent=body, fontName=PDF_FONT_BOLD, fontSize=8.2)
    story=[]
    logo=os.path.join(BASE,"static","logo.png")
    if not os.path.exists(logo): logo=os.path.join(BASE,"static","logo.jpg")
    logo_cell=fit_pdf_image(logo,37*mm,28*mm) if os.path.exists(logo) else Paragraph("<b>PC SERVICES</b>",label)
    company=(f"<b>{_safe(s.get('company_name','P C Services'))}</b><br/>"
             f"{_safe(s.get('company_address',''))}<br/>"
             f"GSTIN: {_safe(s.get('company_gstin',''))}<br/>"
             f"Email: {_safe(s.get('company_email',''))}<br/>Phone: {_safe(s.get('company_phone',''))}")
    header=Table([[logo_cell,Paragraph(company,body),Paragraph("<font size='8'>ORIGINAL</font><br/><br/><font size='18'><b>TAX INVOICE</b></font>",heading)]],colWidths=[40*mm,86*mm,55*mm])
    header.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"MIDDLE"),("BOX",(0,0),(-1,-1),0.7,colors.HexColor('#a8a8a8')),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7)]))
    story.append(header)
    meta_left=Paragraph(f"Invoice No. <b>: {_safe(inv['invoice_no'])}</b><br/>Invoice Date <b>: {_safe(inv['invoice_date'])}</b><br/>Terms <b>: Due on Receipt</b><br/>Due Date <b>: {_safe(inv['invoice_date'])}</b>",body)
    meta_right=Paragraph(f"Place Of Supply <b>: {_safe(inv['state'] or s.get('company_state','Madhya Pradesh'))}</b><br/>Purchase Order No. <b>: {_safe(inv['po_number'] or '—')}</b><br/>PO Date <b>: {_safe(inv['po_date'] or '—')}</b>",body)
    meta=Table([[meta_left,meta_right]],colWidths=[90*mm,91*mm])
    meta.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.6,colors.HexColor('#a8a8a8')),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)])); story.append(meta)
    bill=Paragraph(f"<b>Bill To</b><br/>{_safe(inv['company_name'])}<br/>{_safe(inv['billing_address'] or '')}<br/>GSTIN: {_safe(inv['gstin'] or '—')}<br/>Contact: {_safe(inv['mobile'] or '')}",body)
    ship=Paragraph(f"<b>Ship To</b><br/>{_safe(inv['company_name'])}<br/>{_safe(inv['shipping_address'] or inv['billing_address'] or '')}<br/>GSTIN: {_safe(inv['gstin'] or '—')}<br/>Contact: {_safe(inv['mobile'] or '')}",body)
    parties=Table([[Paragraph("<b>Bill To</b>",label),Paragraph("<b>Ship To</b>",label)],[bill,ship]],colWidths=[90*mm,91*mm])
    parties.setStyle(TableStyle([("SPAN",(0,0),(0,0)),("SPAN",(1,0),(1,0)),("BACKGROUND",(0,0),(-1,0),colors.HexColor('#eeeeee')),("GRID",(0,0),(-1,-1),0.6,colors.HexColor('#a8a8a8')),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),5)])); story.append(parties)
    # GST columns match the reference invoice: HSN/SAC, Qty, Rate, CGST %, amount, SGST %, amount.
    data=[["Sr. No.","Item & Description","HSN/SAC","Qty","Rate","CGST %","CGST Amt","SGST %","SGST Amt","Amount"]]
    subtotal=0.0
    for n,it in enumerate(items,1):
        amt=float(it['amount'] or 0); subtotal+=amt
        data.append([str(n),Paragraph(_safe(it['description'] or ''),tiny),"",f"{float(it['qty'] or 0):.2f}",f"{float(it['rate'] or 0):,.2f}",f"{float(inv['cgst_rate'] or 0):g}%",f"{(amt*float(inv['cgst_rate'] or 0)/100):,.2f}",f"{float(inv['sgst_rate'] or 0):g}%",f"{(amt*float(inv['sgst_rate'] or 0)/100):,.2f}",f"{amt:,.2f}"])
    widths=[12*mm,42*mm,18*mm,12*mm,20*mm,13*mm,17*mm,13*mm,17*mm,17*mm]
    item_table=Table(data,colWidths=widths,repeatRows=1)
    item_table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor('#eeeeee')),("FONTNAME",(0,0),(-1,0),PDF_FONT_BOLD),("GRID",(0,0),(-1,-1),0.55,colors.HexColor('#a8a8a8')),("ALIGN",(3,1),(-1,-1),"RIGHT"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("FONTSIZE",(0,0),(-1,-1),7.2),("LEFTPADDING",(0,0),(-1,-1),3),("RIGHTPADDING",(0,0),(-1,-1),3),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)])); story.append(item_table)
    story.append(Spacer(1,2*mm))
    total_words=number_to_words_indian(float(inv['total'] or 0)) if 'number_to_words_indian' in globals() else ""
    notes=Paragraph(f"<b>Total In Words</b><br/><i>{_safe(total_words)}</i><br/><br/><b>Notes</b><br/>Thank you for your support. We truly appreciate your business and look forward to serving you again.<br/><br/><b>Company's Bank Details</b><br/>Bank Name: {_safe(s.get('bank_name',''))}<br/>A/c No.: {_safe(s.get('bank_account',''))}<br/>Branch &amp; IFSC: {_safe(s.get('bank_ifsc',''))}<br/><br/><b>Terms &amp; Conditions</b><br/>{_safe(s.get('invoice_terms','1. Invoice is due as per agreed payment terms.'))}",tiny)
    total=Table([["Sub Total",f"{float(inv['subtotal'] or 0):,.2f}"],[f"CGST ({float(inv['cgst_rate'] or 0):g}%)",f"{float(inv['cgst'] or 0):,.2f}"],[f"SGST ({float(inv['sgst_rate'] or 0):g}%)",f"{float(inv['sgst'] or 0):,.2f}"],[f"IGST ({float(inv['igst_rate'] or 0):g}%)",f"{float(inv['igst'] or 0):,.2f}"],["Total",f"₹ {float(inv['total'] or 0):,.2f}"],["Balance Due",f"₹ {float(inv['total'] or 0):,.2f}"]],colWidths=[35*mm,30*mm])
    total.setStyle(TableStyle([("ALIGN",(1,0),(1,-1),"RIGHT"),("FONTNAME",(0,0),(-1,-1),PDF_FONT),("FONTNAME",(0,4),(-1,-1),PDF_FONT_BOLD),("LINEABOVE",(0,4),(-1,4),0.7,colors.HexColor('#999999')),("GRID",(0,0),(-1,-1),0.45,colors.HexColor('#b4b4b4')),("BACKGROUND",(0,4),(-1,4),colors.HexColor('#f1f5f9')),("FONTSIZE",(0,0),(-1,-1),8),("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
    signature_name=s.get('signature_image',''); sig=os.path.join(UPLOADS,signature_name) if signature_name and signature_name not in ('logo.png','logo.jpg') else ''
    sig_content=fit_pdf_image(sig,34*mm,16*mm) if sig and os.path.exists(sig) else Paragraph("",body)
    sign_table=Table([[Paragraph(f"<b>{_safe(s.get('authorized_signatory','Ranveer Singh'))}</b>",body)],[sig_content],[Paragraph("Authorized Signature<br/>Digitally recorded date/time: "+_safe(inv['signed_at']),tiny)]],colWidths=[65*mm],rowHeights=[8*mm,18*mm,13*mm])
    sign_table.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("BOX",(0,0),(-1,-1),0.6,colors.HexColor('#a8a8a8'))]))
    lower=Table([[notes,Table([[total],[sign_table]],colWidths=[65*mm])]],colWidths=[116*mm,65*mm])
    lower.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.55,colors.HexColor('#a8a8a8')),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),6),("BOTTOMPADDING",(0,0),(-1,-1),6)])); story.append(lower)
    story.append(Spacer(1,4*mm)); story.append(Paragraph("This is a computer generated invoice.",tiny))
    doc.build(story)
    if not os.path.exists(path) or os.path.getsize(path)==0: raise RuntimeError("PDF file was not created")
    return path

@app.route("/admin/invoices/<int:iid>")
@login_required
def invoice_detail(iid):
    c=db()
    inv=c.execute("""SELECT i.*,c.company_name,c.email,c.mobile FROM invoices i JOIN customers c ON c.id=i.customer_id
                     WHERE i.id=?""",(iid,)).fetchone()
    c.close()
    return render_template("invoice_detail.html", inv=inv)

@app.route("/admin/invoices/<int:iid>/pdf")
@login_required
def invoice_pdf(iid):
    c=db(); inv=c.execute("SELECT * FROM invoices WHERE id=?",(iid,)).fetchone(); c.close()
    if not inv: return "Invoice not found",404
    path = inv["pdf_path"]
    if not path or not os.path.exists(path):
        path = create_invoice_pdf(iid)
        c = db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (path, iid)); c.commit(); c.close()
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="application/pdf")

@app.route("/admin/invoices/<int:iid>/email", methods=["GET","POST"])
@login_required
def email_invoice(iid):
    c=db()
    inv=c.execute("""SELECT i.*,c.company_name,c.email FROM invoices i JOIN customers c ON c.id=i.customer_id
                     WHERE i.id=?""",(iid,)).fetchone()
    c.close()
    s=settings()
    if request.method=="POST":
        to=request.form.get("to","").strip()
        subject=request.form.get("subject","")
        body=request.form.get("body","")
        if not to:
            flash("Customer email is required.","error")
            return redirect(url_for("email_invoice",iid=iid))
        if not s.get("smtp_host") or not s.get("smtp_password"):
            log_email(to,subject,"invoice","Failed","SMTP host/password missing")
            flash("SMTP is not configured yet. Go to Settings and enter your GoDaddy SMTP details.","error")
            return redirect(url_for("email_invoice",iid=iid))
        try:
            msg=EmailMessage()
            msg["From"]=s.get("smtp_user") or "Ranveer@pcservicess.com"
            msg["To"]=to
            msg["Subject"]=subject
            msg.set_content(body + "\n\n" + s.get("email_signature",""))
            path=inv["pdf_path"] or create_invoice_pdf(iid)
            with open(path,"rb") as f:
                msg.add_attachment(f.read(), maintype="application", subtype="pdf", filename=os.path.basename(path))
            port=int(s.get("smtp_port","587"))
            if s.get("smtp_security")=="SSL":
                with smtplib.SMTP_SSL(s["smtp_host"],port,timeout=30) as server:
                    server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
            else:
                with smtplib.SMTP(s["smtp_host"],port,timeout=30) as server:
                    server.ehlo()
                    server.starttls(); server.ehlo()
                    server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
            log_email(to,subject,"invoice","Sent","")
            flash("Invoice email sent with PDF attachment.","success")
        except Exception as e:
            log_email(to,subject,"invoice","Failed",str(e))
            flash("Email failed: "+str(e),"error")
        return redirect(url_for("invoice_detail",iid=iid))
    subject=s["email_subject"].format(invoice_no=inv["invoice_no"])
    body=s["email_body"].format(customer=inv["company_name"],invoice_no=inv["invoice_no"])
    return render_template("email_invoice.html", inv=inv, subject=subject, body=body, signature=s.get("email_signature",""))

@app.route("/admin/users", methods=["GET", "POST"])
@login_required
def user_setup():
    c = db()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "customer")
        if role not in ("customer","admin","staff","technician"): role="customer"
        permissions = [x for x in request.form.getlist("permissions[]") if x in {"dashboard","customers","products","invoices","vendors","employees","service_categories","rental_equipment","purchases","payments","quotes","rentals","service_jobs","reports","quote_requests","stock_movements","product_master"}]
        customer_id = request.form.get("customer_id") or None
        full_name = request.form.get("full_name", "").strip()
        if not username or not password:
            flash("Username and password are required.", "error")
        elif role == "customer" and not customer_id:
            flash("Please select a customer for a customer login.", "error")
        elif role in ("staff","technician") and not permissions:
            flash("Select at least one module permission for this staff login.", "error")
        else:
            try:
                c.execute("INSERT INTO users(username,password_hash,role,customer_id,full_name,active,created_at) VALUES(?,?,?,?,?,?,?)",
                          (username, generate_password_hash(password), role, customer_id if role == "customer" else None,
                           full_name, 1, datetime.now().isoformat(timespec="seconds")))
                new_user_id=c.execute("SELECT id FROM users WHERE username=?",(username,)).fetchone()["id"]
                if role in ("staff","technician"):
                    for module in set(permissions+(["dashboard"] if "dashboard" not in permissions else [])):
                        c.execute("INSERT OR IGNORE INTO user_permissions(user_id,module) VALUES(?,?)",(new_user_id,module))
                c.commit()
                flash("User login created successfully.", "success")
            except sqlite3.IntegrityError:
                flash("Username already exists. Please use another username.", "error")
        c.close()
        return redirect(url_for("user_setup"))
    users = c.execute("""SELECT u.*, c.company_name FROM users u LEFT JOIN customers c ON c.id=u.customer_id ORDER BY u.id DESC""").fetchall()
    user_module_map={u["id"]:[r["module"] for r in c.execute("SELECT module FROM user_permissions WHERE user_id=?",(u["id"],)).fetchall()] for u in users}
    customers_list = c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall()
    c.close()
    return render_template("users.html", users=users, customers=customers_list, user_module_map=user_module_map)

@app.route("/admin/users/<int:uid>/permissions", methods=["POST"])
@login_required
def update_user_permissions(uid):
    allowed={"dashboard","customers","products","invoices","vendors","employees","service_categories","rental_equipment","purchases","payments","quotes","rentals","service_jobs","reports","quote_requests","stock_movements","product_master"}
    modules=[x for x in request.form.getlist("permissions[]") if x in allowed]
    if "dashboard" not in modules: modules.append("dashboard")
    c=db(); user=c.execute("SELECT role FROM users WHERE id=?",(uid,)).fetchone()
    if not user or user["role"] not in ("staff","technician"):
        c.close(); flash("Module permissions can only be assigned to Staff / Technician users.","error"); return redirect(url_for("user_setup"))
    c.execute("DELETE FROM user_permissions WHERE user_id=?",(uid,))
    for module in set(modules): c.execute("INSERT OR IGNORE INTO user_permissions(user_id,module) VALUES(?,?)",(uid,module))
    c.commit(); c.close(); flash("Authorized modules updated.","success"); return redirect(url_for("user_setup"))

@app.route("/admin/users/<int:uid>/toggle", methods=["POST"])
@login_required
def toggle_user(uid):
    c = db()
    user = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not user:
        c.close(); return "User not found", 404
    if user["username"] == "admin" and user["role"] == "admin":
        flash("The default admin account cannot be disabled from this page.", "error")
    else:
        c.execute("UPDATE users SET active=? WHERE id=?", (0 if user["active"] else 1, uid))
        c.commit()
        flash("User status updated.", "success")
    c.close()
    return redirect(url_for("user_setup"))

@app.route("/admin/users/<int:uid>/password", methods=["POST"])
@login_required
def change_user_password(uid):
    password = request.form.get("password", "")
    if len(password) < 6:
        flash("Password must be at least 6 characters.", "error")
        return redirect(url_for("user_setup"))
    c = db()
    c.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(password), uid))
    c.commit(); c.close()
    flash("Password updated successfully.", "success")
    return redirect(url_for("user_setup"))

@app.route("/customer")
@customer_required
def customer_dashboard():
    c = db()
    customer = c.execute("SELECT * FROM customers WHERE id=?", (session["customer_id"],)).fetchone()
    invoices = c.execute("SELECT * FROM invoices WHERE customer_id=? ORDER BY id DESC", (session["customer_id"],)).fetchall()
    total = c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices WHERE customer_id=?", (session["customer_id"],)).fetchone()["n"]
    payments = c.execute("SELECT p.*,i.invoice_no FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE i.customer_id=? AND p.active=1 ORDER BY p.payment_date DESC,p.id DESC",(session["customer_id"],)).fetchall()
    c.close()
    return render_template("customer_dashboard.html", customer=customer, invoices=invoices, total=total, payments=payments)

@app.route("/customer/invoices/<int:iid>")
@customer_required
def customer_invoice_detail(iid):
    c = db()
    inv = c.execute("""SELECT i.*, c.company_name,c.contact_person,c.mobile,c.email,c.gstin,c.billing_address
                       FROM invoices i JOIN customers c ON c.id=i.customer_id
                       WHERE i.id=? AND i.customer_id=?""", (iid, session["customer_id"])).fetchone()
    items = c.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (iid,)).fetchall() if inv else []
    c.close()
    if not inv: return "Invoice not found", 404
    return render_template("customer_invoice_detail.html", inv=inv, items=items)

@app.route("/customer/invoices/<int:iid>/pdf")
@customer_required
def customer_invoice_pdf(iid):
    c = db()
    inv = c.execute("SELECT * FROM invoices WHERE id=? AND customer_id=?", (iid, session["customer_id"])).fetchone()
    c.close()
    if not inv: return "Invoice not found", 404
    path = inv["pdf_path"]
    if not path or not os.path.exists(path):
        path = create_invoice_pdf(iid)
        c = db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?", (path, iid)); c.commit(); c.close()
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="application/pdf")

@app.route("/admin/settings", methods=["GET","POST"])
@login_required
def admin_settings():
    if request.method=="POST":
        for k in ["company_name","company_email","quote_admin_email","company_phone","company_address","gstin","invoice_prefix",
                  "email_signature","email_subject","email_body","smtp_host","smtp_port","smtp_user","smtp_security"]:
            set_setting(k,request.form.get(k,""))
        # Do not erase a saved SMTP password when the masked field is left blank.
        if request.form.get("smtp_password", "").strip():
            set_setting("smtp_password_enc", encrypt_secret(request.form["smtp_password"]))
            # Remove the legacy plaintext field after encrypted storage is saved.
            c = db(); c.execute("DELETE FROM settings WHERE key='smtp_password'"); c.commit(); c.close()
        f=request.files.get("signature")
        if f and f.filename:
            ext=os.path.splitext(f.filename)[1].lower()
            if ext in [".png",".jpg",".jpeg"]:
                name="signature"+ext
                f.save(os.path.join(UPLOADS,name))
                set_setting("signature_image",name)
        flash("Settings saved.","success")
        return redirect(url_for("admin_settings"))
    return render_template("settings.html", s=settings())

@app.route("/admin/settings/test-email", methods=["POST"])
@login_required
def test_email():
    s=settings()
    try:
        if not s.get("smtp_host") or not s.get("smtp_password"):
            raise ValueError("SMTP host/password missing")
        msg=EmailMessage()
        msg["From"]=s["smtp_user"]; msg["To"]=s["smtp_user"]; msg["Subject"]="PC SERVICES SMTP Test"
        msg.set_content("SMTP connection test successful.")
        port=int(s.get("smtp_port","587"))
        if s.get("smtp_security")=="SSL":
            with smtplib.SMTP_SSL(s["smtp_host"],port,timeout=30) as server:
                server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
        else:
            with smtplib.SMTP(s["smtp_host"],port,timeout=30) as server:
                server.starttls(); server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
        log_email(s.get("smtp_user",""),"PC SERVICES SMTP Test","smtp_test","Sent","")
        flash("Test email sent successfully.","success")
    except Exception as e:
        log_email(s.get("smtp_user",""),"PC SERVICES SMTP Test","smtp_test","Failed",str(e))
        flash("SMTP test failed: "+str(e),"error")
    return redirect(url_for("admin_settings"))



@app.route("/admin/invoices/<int:iid>/edit", methods=["GET","POST"])
@login_required
def edit_invoice(iid):
    c=db(); inv=c.execute("SELECT * FROM invoices WHERE id=?",(iid,)).fetchone()
    if not inv: c.close(); return "Invoice not found",404
    old_items=c.execute("SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id",(iid,)).fetchall()
    customers_list=c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall()
    products_list=c.execute("SELECT * FROM products WHERE active=1 ORDER BY product_name").fetchall()
    if request.method=="GET":
        c.close(); return render_template("invoice_edit.html",inv=inv,items=old_items,customers=customers_list,products=products_list)
    before={"invoice":dict(inv),"items":[dict(x) for x in old_items]}
    try:
        customer_id=int(request.form["customer_id"]); invoice_date=request.form.get("invoice_date") or inv["invoice_date"]
        descriptions=request.form.getlist("description[]"); qtys=request.form.getlist("qty[]"); rates=request.form.getlist("rate[]"); product_ids=request.form.getlist("product_id[]")
        items=[]; subtotal=0.0
        for idx,(desc,qty_raw,rate_raw) in enumerate(zip(descriptions,qtys,rates)):
            desc=desc.strip()
            if not desc: continue
            qty=float(qty_raw or 0); rate=float(rate_raw or 0)
            if qty<=0 or rate<0: raise ValueError("Each invoice item must have quantity above zero and a non-negative rate.")
            pid=int(product_ids[idx]) if idx<len(product_ids) and product_ids[idx] else None
            amount=round(qty*rate,2); subtotal+=amount; items.append((desc,qty,rate,amount,pid))
        if not items: raise ValueError("Add at least one invoice item.")
        cgst_rate=max(0,float(request.form.get("cgst_rate","0") or 0)); sgst_rate=max(0,float(request.form.get("sgst_rate","0") or 0)); igst_rate=max(0,float(request.form.get("igst_rate","0") or 0))
        cgst=round(subtotal*cgst_rate/100,2); sgst=round(subtotal*sgst_rate/100,2); igst=round(subtotal*igst_rate/100,2); total=round(subtotal+cgst+sgst+igst,2)
        # Restore stock only for line items that this app previously deducted; older records are not guessed.
        for old in old_items:
            if old["product_id"] and old["cost_at_sale"] is not None:
                c.execute("UPDATE products SET stock_qty=COALESCE(stock_qty,0)+? WHERE id=?",(old["qty"],old["product_id"]))
                balance=c.execute("SELECT stock_qty FROM products WHERE id=?",(old["product_id"],)).fetchone()["stock_qty"]
                c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity_change,balance_after,reference_type,reference_id,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(old["product_id"],"Invoice Edit Restock",old["qty"],balance,"invoice",iid,"Restore previous invoice line",datetime.now().isoformat(timespec="seconds")))
        c.execute("DELETE FROM invoice_items WHERE invoice_id=?",(iid,))
        for desc,qty,rate,amount,pid in items:
            cost=None
            if pid:
                product=c.execute("SELECT purchase_price,stock_qty FROM products WHERE id=?",(pid,)).fetchone()
                if product:
                    cost=float(product["purchase_price"] or 0)
                    if float(product["stock_qty"] or 0)<qty: flash(f"Stock warning: {desc} will result in negative stock; sale is allowed.","error")
                    c.execute("UPDATE products SET stock_qty=COALESCE(stock_qty,0)-? WHERE id=?",(qty,pid))
                    balance=c.execute("SELECT stock_qty FROM products WHERE id=?",(pid,)).fetchone()["stock_qty"]
                    c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity_change,balance_after,reference_type,reference_id,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(pid,"Invoice Edit Sale",-qty,balance,"invoice",iid,"Updated invoice line",datetime.now().isoformat(timespec="seconds")))
            c.execute("INSERT INTO invoice_items(invoice_id,description,qty,rate,amount,product_id,cost_at_sale) VALUES(?,?,?,?,?,?,?)",(iid,desc,qty,rate,amount,pid,cost))
        paid=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE invoice_id=? AND active=1",(iid,)).fetchone()["n"]
        status="Paid" if paid>=total else ("Partial" if paid>0 else "Pending")
        signed_at=datetime.now().strftime("%d-%m-%Y %I:%M:%S %p")
        po_number=request.form.get("po_number", "").strip() or None
        po_date=request.form.get("po_date", "").strip() or None
        c.execute("UPDATE invoices SET customer_id=?,invoice_date=?,subtotal=?,cgst=?,sgst=?,igst=?,cgst_rate=?,sgst_rate=?,igst_rate=?,total=?,status=?,signed_at=?,po_number=?,po_date=? WHERE id=?",
                  (customer_id,invoice_date,subtotal,cgst,sgst,igst,cgst_rate,sgst_rate,igst_rate,total,status,signed_at,po_number,po_date,iid))
        c.commit()
        after_inv=c.execute("SELECT * FROM invoices WHERE id=?",(iid,)).fetchone(); after_items=c.execute("SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id",(iid,)).fetchall(); c.close()
        audit("invoice",iid,"issued_invoice_edited",before,{"invoice":dict(after_inv),"items":[dict(x) for x in after_items]})
        try:
            pdf=create_invoice_pdf(iid); c=db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?",(pdf,iid)); c.commit(); c.close()
            flash("Invoice updated; before/after values saved in Audit History and PDF regenerated.","success")
        except Exception as exc: flash("Invoice updated, but PDF regeneration failed: "+str(exc),"error")
        return redirect(url_for("invoice_detail",iid=iid))
    except (ValueError,KeyError) as exc:
        c.rollback(); c.close(); flash(str(exc),"error")
        return redirect(url_for("edit_invoice",iid=iid))


def create_quote_pdf(qid):
    c=db(); quote=c.execute("SELECT q.*,c.company_name,c.contact_person,c.email,c.mobile,c.gstin,c.billing_address FROM quotes q JOIN customers c ON c.id=q.customer_id WHERE q.id=?",(qid,)).fetchone(); c.close()
    if not quote: raise ValueError("Quotation not found")
    s=settings(); path=os.path.join(QUOTE_DIR,f"{quote['quote_no']}.pdf")
    doc=SimpleDocTemplate(path,pagesize=A4,rightMargin=14*mm,leftMargin=14*mm,topMargin=12*mm,bottomMargin=12*mm)
    styles=getSampleStyleSheet(); normal=ParagraphStyle("qnormal",parent=styles["Normal"],fontName=PDF_FONT,fontSize=9,leading=12); title=ParagraphStyle("qtitle",parent=styles["Title"],fontName=PDF_FONT_BOLD,fontSize=18,leading=22,alignment=TA_RIGHT)
    story=[]; logo=os.path.join(BASE,"static","logo.png")
    if os.path.exists(logo): story.append(fit_pdf_image(logo,45*mm,23*mm))
    story.append(Paragraph(f"<b>{_safe(s.get('company_name','PC SERVICES'))}</b><br/>{_safe(s.get('company_address',''))}<br/>Phone: {_safe(s.get('company_phone',''))} | Email: {_safe(s.get('company_email',''))}",normal))
    story += [Spacer(1,5*mm),Paragraph("QUOTATION / ESTIMATE",title),Paragraph(f"<b>Quote No:</b> {_safe(quote['quote_no'])} &nbsp;&nbsp; <b>Date:</b> {_safe(quote['quote_date'])}<br/><b>Valid Until:</b> {_safe(quote['valid_until'] or 'Not specified')}",normal),Spacer(1,4*mm)]
    story.append(Paragraph(f"<b>Prepared For:</b> {_safe(quote['company_name'])}<br/>{_safe(quote['billing_address'] or '')}<br/>Contact: {_safe(quote['contact_person'] or '')} | {_safe(quote['mobile'] or '')}<br/>GSTIN: {_safe(quote['gstin'] or '')}",normal)); story.append(Spacer(1,5*mm))
    detail=Paragraph(_safe(quote["description"] or "Supply / service as discussed"),normal)
    tax_label=f"GST ({_safe(quote['gst_type'] or 'CGST+SGST')} @ {float(quote['gst_rate'] or 0):g}%)"
    c=db(); quote_items=c.execute("SELECT * FROM quote_items WHERE quote_id=? ORDER BY id",(qid,)).fetchall(); c.close()
    if quote_items:
        data=[["#","Item / Description","Qty","Unit Price","GST %","Amount"]]
        for n,it in enumerate(quote_items,1):
            data.append([str(n),_safe(it["description"]),f"{it['qty']:g}",f"Rs. {float(it['rate']):,.2f}",f"{float(it['gst_rate']):g}%",f"Rs. {float(it['amount']):,.2f}"])
        data += [["","Subtotal","","","",f"Rs. {float(quote['taxable_amount'] or 0):,.2f}"],["",tax_label,"","","",f"Rs. {float(quote['gst_amount'] or 0):,.2f}"],["","TOTAL","","","",f"Rs. {float(quote['total'] or 0):,.2f}"]]
        table=Table(data,colWidths=[8*mm,64*mm,15*mm,27*mm,18*mm,35*mm],repeatRows=1)
    else:
        data=[["Description / Scope","Taxable Amount"],[detail,f"Rs. {float(quote['taxable_amount'] or 0):,.2f}"],[tax_label,f"Rs. {float(quote['gst_amount'] or 0):,.2f}"],["Total Quotation Value",f"Rs. {float(quote['total'] or 0):,.2f}"]]
        table=Table(data,colWidths=[112*mm,55*mm],repeatRows=1)
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#12365b")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,-1),PDF_FONT),("FONTNAME",(0,0),(-1,0),PDF_FONT_BOLD),("FONTNAME",(0,-1),(-1,-1),PDF_FONT_BOLD),("GRID",(0,0),(-1,-1),0.5,colors.HexColor("#d8e0ea")),("BACKGROUND",(0,-1),(-1,-1),colors.HexColor("#eef6ff")),("VALIGN",(0,0),(-1,-1),"TOP"),("FONTSIZE",(0,0),(-1,-1),9),("LEFTPADDING",(0,0),(-1,-1),8),("RIGHTPADDING",(0,0),(-1,-1),8),("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8)]))
    story.append(table); story += [Spacer(1,8*mm),Paragraph("This quotation is subject to final confirmation of scope, availability and agreed commercial terms.",normal),Spacer(1,8*mm),Paragraph("For PC SERVICES<br/><br/><b>Authorized Signatory</b>",normal)]
    doc.build(story)
    if not os.path.exists(path) or os.path.getsize(path)==0: raise RuntimeError("Quotation PDF was not created")
    return path

@app.route("/admin/quotes/<int:qid>")
@login_required
def quote_detail(qid):
    c=db(); quote=c.execute("SELECT q.*,c.company_name,c.email,c.mobile,c.gstin,c.billing_address FROM quotes q JOIN customers c ON c.id=q.customer_id WHERE q.id=?",(qid,)).fetchone(); c.close()
    if not quote: return "Quotation not found",404
    s=settings(); return render_template("quote_detail.html",quote=quote,company_name=s.get("company_name","PC SERVICES"),company_address=s.get("company_address",""),company_phone=s.get("company_phone",""),company_email=s.get("company_email",""))

@app.route("/admin/quotes/<int:qid>/pdf")
@login_required
def quote_pdf(qid):
    try: path=create_quote_pdf(qid)
    except Exception as exc: flash("Quotation PDF generation failed: "+str(exc),"error"); return redirect(url_for("quotes_module"))
    return send_file(path,as_attachment=True,download_name=os.path.basename(path),mimetype="application/pdf")

@app.route("/admin/quotes/<int:qid>/print")
@login_required
def quote_print(qid):
    c=db(); quote=c.execute("SELECT q.*,c.company_name,c.email,c.mobile,c.gstin,c.billing_address FROM quotes q JOIN customers c ON c.id=q.customer_id WHERE q.id=?",(qid,)).fetchone(); c.close()
    if not quote: return "Quotation not found",404
    s=settings(); return render_template("quote_detail.html",quote=quote,print_mode=True,company_name=s.get("company_name","PC SERVICES"),company_address=s.get("company_address",""),company_phone=s.get("company_phone",""),company_email=s.get("company_email",""))

@app.route("/admin/quotes/<int:qid>/email",methods=["GET","POST"])
@login_required
def quote_email(qid):
    c=db(); quote=c.execute("SELECT q.*,c.company_name,c.email FROM quotes q JOIN customers c ON c.id=q.customer_id WHERE q.id=?",(qid,)).fetchone(); c.close()
    if not quote: return "Quotation not found",404
    if request.method=="POST":
        recipient=request.form.get("to","").strip(); subject=request.form.get("subject","").strip(); body=request.form.get("body","")
        if not recipient: flash("Recipient email is required.","error"); return redirect(url_for("quote_email",qid=qid))
        try: path=create_quote_pdf(qid)
        except Exception as exc: flash("Quotation PDF generation failed: "+str(exc),"error"); return redirect(url_for("quote_email",qid=qid))
        ok,error=send_business_email(recipient,subject,body,"quotation",[(path,os.path.basename(path))])
        if ok: flash("Quotation email sent with PDF attachment.","success")
        else: flash("Quotation email failed: "+error,"error")
        return redirect(url_for("quote_detail",qid=qid))
    return render_template("quote_email.html",quote=quote,subject=f"Quotation {quote['quote_no']} from PC SERVICES",body=f"Dear {quote['company_name']},\n\nPlease find attached quotation {quote['quote_no']}.\n\nThank you for considering PC SERVICES.")

@app.route("/admin/quotes/<int:qid>/convert", methods=["POST"])
@login_required
def convert_quote_to_invoice(qid):
    c=db(); quote=c.execute("SELECT * FROM quotes WHERE id=?",(qid,)).fetchone()
    if not quote: c.close(); return "Quotation not found",404
    if quote["status"] in ("Rejected","Expired","Converted"):
        c.close(); flash("This quotation cannot be converted in its current status.","error"); return redirect(url_for("quotes_module"))
    now=datetime.now(); invoice_no=next_invoice_number(c, now)
    taxable=float(quote["taxable_amount"] or 0); rate=float(quote["gst_rate"] or 0); gst_type=quote["gst_type"] or "CGST+SGST"
    if gst_type=="IGST": cgst_rate=sgst_rate=0.0; igst_rate=rate
    else: cgst_rate=sgst_rate=rate/2; igst_rate=0.0
    cgst=round(taxable*cgst_rate/100,2); sgst=round(taxable*sgst_rate/100,2); igst=round(taxable*igst_rate/100,2); total=round(taxable+cgst+sgst+igst,2)
    cur=c.execute("INSERT INTO invoices(invoice_no,customer_id,invoice_date,subtotal,cgst,sgst,igst,cgst_rate,sgst_rate,igst_rate,total,status,signed_at,created_at,quote_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      (invoice_no,quote["customer_id"],now.strftime('%Y-%m-%d'),taxable,cgst,sgst,igst,cgst_rate,sgst_rate,igst_rate,total,"Pending",now.strftime("%d-%m-%Y %I:%M:%S %p"),now.isoformat(timespec="seconds"),qid))
    iid=cur.lastrowid; desc=quote["description"] or ("Quotation " + quote["quote_no"])
    c.execute("INSERT INTO invoice_items(invoice_id,description,qty,rate,amount,product_id,cost_at_sale) VALUES(?,?,?,?,?,?,?)",(iid,desc,1,taxable,taxable,None,None))
    c.execute("UPDATE quotes SET status='Converted' WHERE id=?",(qid,)); c.commit(); c.close()
    audit("quote",qid,"converted_to_invoice",dict(quote),{"invoice_id":iid,"invoice_no":invoice_no})
    try:
        pdf=create_invoice_pdf(iid); c=db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?",(pdf,iid)); c.commit(); c.close(); flash("Quotation converted to invoice and PDF generated.","success")
    except Exception as exc: flash("Invoice created from quotation, but PDF generation failed: "+str(exc),"error")
    return redirect(url_for("invoice_detail",iid=iid))

# ---------------- New incremental business modules ----------------
def audit(entity_type, entity_id, action, before=None, after=None):
    import json
    c=db()
    c.execute("INSERT INTO audit_log(entity_type,entity_id,action,before_json,after_json,actor,created_at) VALUES(?,?,?,?,?,?,?)",
              (entity_type,entity_id,action,json.dumps(before,default=str) if before is not None else None,
               json.dumps(after,default=str) if after is not None else None,session.get("username","public"),datetime.now().isoformat(timespec="seconds")))
    c.commit(); c.close()

def log_email(recipient, subject, kind, status, error=""):
    c=db(); c.execute("INSERT INTO email_logs(recipient,subject,kind,status,error,created_at) VALUES(?,?,?,?,?,?)",
                      (recipient,subject,kind,status,(error or "")[:1000],datetime.now().isoformat(timespec="seconds"))); c.commit(); c.close()

def send_business_email(recipient, subject, body, kind="general", attachments=None):
    s=settings()
    try:
        if not s.get("smtp_host") or not s.get("smtp_user") or not s.get("smtp_password"):
            raise ValueError("SMTP host, username or password missing. Configure GoDaddy SMTP in Admin Settings.")
        msg=EmailMessage(); msg["From"]=s.get("smtp_user"); msg["To"]=recipient; msg["Subject"]=subject
        msg.set_content(body + ("\n\n"+s.get("email_signature","") if s.get("email_signature") else ""))
        for file_path, display_name in (attachments or []):
            with open(file_path,"rb") as handle:
                msg.add_attachment(handle.read(),maintype="application",subtype="pdf",filename=display_name or os.path.basename(file_path))
        port=int(s.get("smtp_port") or 587)
        if s.get("smtp_security")=="SSL":
            with smtplib.SMTP_SSL(s["smtp_host"],port,timeout=30) as server:
                server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
        else:
            with smtplib.SMTP(s["smtp_host"],port,timeout=30) as server:
                server.ehlo(); server.starttls(); server.ehlo(); server.login(s["smtp_user"],s["smtp_password"]); server.send_message(msg)
        log_email(recipient,subject,kind,"Sent","")
        return True, ""
    except Exception as exc:
        log_email(recipient,subject,kind,"Failed",str(exc))
        return False, str(exc)

@app.route("/admin/masters/<kind>", methods=["GET","POST"])
@login_required
def master_module(kind):
    configs={
      "vendors":{"title":"Vendor / Supplier Master","table":"vendors","fields":[("name","Name","text",True),("contact_person","Contact Person","text",False),("mobile","Mobile","text",False),("email","Email","email",False),("gstin","GSTIN","text",False),("address","Address","text",False),("notes","Notes","text",False)],"cols":["name","contact_person","mobile","email","gstin"]},
      "employees":{"title":"Employee Master","table":"employees","fields":[("name","Employee Name","text",True),("role","Role (admin/staff/technician)","text",True),("mobile","Mobile","text",False),("email","Email","email",False)],"cols":["name","role","mobile","email"]},
      "service-categories":{"title":"Service / Repair Category Master","table":"service_categories","fields":[("name","Category Name","text",True),("description","Description","text",False)],"cols":["name","description"]},
      "rental-equipment":{"title":"Rental Equipment Master","table":"rental_equipment","fields":[("equipment_name","Equipment Name","text",True),("serial_no","Serial No.","text",False),("model","Model","text",False),("monthly_rate","Monthly Rent (₹)","number",False),("status","Status","text",False),("notes","Notes","text",False)],"cols":["equipment_name","serial_no","model","monthly_rate","status"]}}
    cfg=configs.get(kind)
    if not cfg: return "Master not found",404
    c=db()
    if request.method=="POST":
        fields=cfg["fields"]; keys=[f[0] for f in fields]; vals=[]
        for key,label,typ,required in fields:
            val=request.form.get(key,"").strip()
            if required and not val:
                flash(label+" is required.","error"); c.close(); return redirect(url_for("master_module",kind=kind))
            if typ=="number":
                try: val=float(val or 0)
                except ValueError: flash(label+" must be numeric.","error"); c.close(); return redirect(url_for("master_module",kind=kind))
            vals.append(val)
        if kind=="employees":
            c.execute("INSERT INTO employees(name,role,mobile,email,active,created_at) VALUES(?,?,?,?,1,?)",(*vals,datetime.now().isoformat(timespec="seconds")))
        elif kind=="service-categories":
            try: c.execute("INSERT INTO service_categories(name,description,active,created_at) VALUES(?,?,1,?)",(*vals,datetime.now().isoformat(timespec="seconds")))
            except sqlite3.IntegrityError: flash("This category already exists.","error"); c.close(); return redirect(url_for("master_module",kind=kind))
        elif kind=="rental-equipment":
            c.execute("INSERT INTO rental_equipment(equipment_name,serial_no,model,monthly_rate,status,notes,created_at) VALUES(?,?,?,?,?,?,?)",(*vals,datetime.now().isoformat(timespec="seconds")))
        else:
            c.execute("INSERT INTO vendors(name,contact_person,mobile,email,gstin,address,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(*vals,datetime.now().isoformat(timespec="seconds")))
        c.commit(); c.close(); flash(cfg["title"]+" saved.","success"); return redirect(url_for("master_module",kind=kind))
    rows=c.execute("SELECT * FROM "+cfg["table"]+" ORDER BY id DESC").fetchall(); c.close()
    return render_template("operations.html",title=cfg["title"],mode="master",fields=cfg["fields"],columns=cfg["cols"],rows=rows,endpoint=url_for("master_module",kind=kind))

@app.route("/admin/purchases", methods=["GET","POST"])
@login_required
def purchases_module():
    c=db()
    if request.method=="POST":
        try:
            product_id=int(request.form["product_id"]); qty=float(request.form.get("qty") or 0); unit_cost=float(request.form.get("unit_cost") or 0)
            if qty<=0 or unit_cost<0: raise ValueError("Quantity must be above zero and unit cost cannot be negative.")
            product=c.execute("SELECT * FROM products WHERE id=?",(product_id,)).fetchone()
            if not product: raise ValueError("Select a valid product.")
            old_qty=float(product["stock_qty"] or 0); old_cost=float(product["purchase_price"] or 0)
            # Weighted average after each purchase; non-positive old stock does not distort the new cost basis.
            base_qty=max(old_qty,0)
            new_qty=old_qty+qty
            weighted=((base_qty*old_cost)+(qty*unit_cost))/(base_qty+qty) if base_qty+qty else unit_cost
            purchase_no="PUR-"+datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            cur=c.execute("INSERT INTO purchases(purchase_no,vendor_id,purchase_date,product_id,qty,unit_cost,amount,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
              (purchase_no,request.form.get("vendor_id") or None,request.form.get("purchase_date") or datetime.now().strftime("%Y-%m-%d"),product_id,qty,unit_cost,qty*unit_cost,request.form.get("notes",""),datetime.now().isoformat(timespec="seconds")))
            c.execute("UPDATE products SET stock_qty=?,purchase_price=? WHERE id=?",(new_qty,weighted,product_id))
            c.execute("INSERT INTO stock_movements(product_id,movement_type,quantity_change,balance_after,reference_type,reference_id,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(product_id,"Purchase",qty,new_qty,"purchase",cur.lastrowid,purchase_no,datetime.now().isoformat(timespec="seconds")))
            c.commit(); audit("purchase",cur.lastrowid,"created",None,{"purchase_no":purchase_no,"product_id":product_id,"qty":qty,"unit_cost":unit_cost,"weighted_average":weighted})
            flash(f"Purchase saved. Stock is now {new_qty:g}; weighted-average cost is ₹{weighted:.2f}.","success")
        except (ValueError,KeyError) as exc:
            flash(str(exc),"error")
        c.close(); return redirect(url_for("purchases_module"))
    products_list=c.execute("SELECT id,product_name,stock_qty,purchase_price FROM products WHERE active=1 ORDER BY product_name").fetchall()
    vendors=c.execute("SELECT id,name FROM vendors ORDER BY name").fetchall()
    rows=c.execute("SELECT p.*,pr.product_name,v.name vendor_name FROM purchases p JOIN products pr ON pr.id=p.product_id LEFT JOIN vendors v ON v.id=p.vendor_id ORDER BY p.id DESC LIMIT 200").fetchall(); c.close()
    return render_template("operations.html",title="Purchase / Stock Inward",mode="purchases",products=products_list,vendors=vendors,rows=rows,columns=["purchase_no","purchase_date","vendor_name","product_name","qty","unit_cost","amount"])

@app.route("/admin/payments", methods=["GET","POST"])
@login_required
def payments_module():
    c=db()
    if request.method=="POST":
        try:
            iid=int(request.form["invoice_id"]); amount=float(request.form.get("amount") or 0)
            if amount<=0: raise ValueError("Payment amount must be greater than zero.")
            inv=c.execute("SELECT * FROM invoices WHERE id=?",(iid,)).fetchone()
            if not inv: raise ValueError("Invoice not found.")
            cur=c.execute("INSERT INTO payments(invoice_id,amount,payment_date,method,reference,notes,created_at,active) VALUES(?,?,?,?,?,?,?,1)",
                (iid,amount,request.form.get("payment_date") or datetime.now().strftime("%Y-%m-%d"),request.form.get("method","Bank Transfer"),request.form.get("reference",""),request.form.get("notes",""),datetime.now().isoformat(timespec="seconds")))
            paid=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE invoice_id=? AND active=1",(iid,)).fetchone()["n"]
            status="Paid" if paid>=float(inv["total"] or 0) else ("Partial" if paid>0 else "Pending")
            c.execute("UPDATE invoices SET status=? WHERE id=?",(status,iid)); c.commit(); c.close()
            audit("payment",cur.lastrowid,"created",None,{"invoice_id":iid,"amount":amount,"status":status})
            flash("Payment recorded as a separate entry.","success")
        except (ValueError,KeyError) as exc:
            c.close(); flash(str(exc),"error")
        return redirect(url_for("payments_module"))
    invs=c.execute("SELECT i.id,i.invoice_no,i.total,c.company_name FROM invoices i JOIN customers c ON c.id=i.customer_id ORDER BY i.id DESC").fetchall()
    customer_id=request.args.get("customer_id","").strip(); customers_list=c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall()
    sql="SELECT p.*,i.invoice_no,c.company_name FROM payments p JOIN invoices i ON i.id=p.invoice_id JOIN customers c ON c.id=i.customer_id WHERE 1=1"; args=[]
    if customer_id: sql+=" AND i.customer_id=?"; args.append(customer_id)
    sql+=" ORDER BY p.id DESC LIMIT 250"; rows=c.execute(sql,args).fetchall()
    out_sql="""SELECT i.id,i.invoice_no,i.po_number,i.invoice_date,i.total,c.company_name,COALESCE(p.paid,0) paid,MAX(i.total-COALESCE(p.paid,0),0) balance,CASE WHEN COALESCE(p.paid,0)<=0 THEN 'Pending' WHEN COALESCE(p.paid,0)<i.total THEN 'Partial' ELSE 'Paid' END payment_state FROM invoices i JOIN customers c ON c.id=i.customer_id LEFT JOIN (SELECT invoice_id,SUM(amount) paid FROM payments WHERE active=1 GROUP BY invoice_id) p ON p.invoice_id=i.id WHERE i.total>COALESCE(p.paid,0)"""
    out_args=[]
    if customer_id: out_sql+=" AND i.customer_id=?"; out_args.append(customer_id)
    out_sql+=" ORDER BY i.invoice_date DESC,i.id DESC"
    outstanding_rows=c.execute(out_sql,out_args).fetchall()
    c.close(); return render_template("operations.html",title="Payments & Outstanding",mode="payments",invoices=invs,customers=customers_list,selected_customer=customer_id,rows=rows,columns=["invoice_no","company_name","payment_date","amount","method","reference","active"],outstanding_rows=outstanding_rows)

@app.route("/admin/payments/<int:pid>/reverse",methods=["POST"])
@login_required
def reverse_payment(pid):
    c=db(); payment=c.execute("SELECT * FROM payments WHERE id=?",(pid,)).fetchone()
    if not payment: c.close(); return "Payment not found",404
    if payment["active"]:
        c.execute("UPDATE payments SET active=0 WHERE id=?",(pid,))
        inv=c.execute("SELECT total FROM invoices WHERE id=?",(payment["invoice_id"],)).fetchone()
        paid=c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE invoice_id=? AND active=1",(payment["invoice_id"],)).fetchone()["n"]
        status="Paid" if paid>=float(inv["total"] or 0) else ("Partial" if paid>0 else "Pending")
        c.execute("UPDATE invoices SET status=? WHERE id=?",(status,payment["invoice_id"]))
        c.commit(); c.close(); audit("payment",pid,"reversed",dict(payment),{"active":0,"recalculated_status":status}); flash("Payment reversed; audit history retained.","success")
    else: c.close(); flash("This payment was already reversed.","error")
    return redirect(url_for("payments_module"))

@app.route("/admin/rentals",methods=["GET","POST"])
@login_required
def rentals_module():
    c=db()
    if request.method=="POST":
        try:
            customer_id=int(request.form["customer_id"]); rent=float(request.form.get("monthly_rent") or 0)
            if rent<0: raise ValueError("Monthly rent cannot be negative.")
            cur=c.execute("INSERT INTO rentals(customer_id,equipment_id,description,start_date,end_date,monthly_rent,gst_rate,gst_type,billing_day,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (customer_id,request.form.get("equipment_id") or None,request.form["description"],request.form["start_date"],request.form.get("end_date") or None,rent,float(request.form.get("gst_rate") or 0),request.form.get("gst_type","CGST+SGST"),int(request.form.get("billing_day") or 1),"Active",request.form.get("notes",""),datetime.now().isoformat(timespec="seconds")))
            if request.form.get("equipment_id"): c.execute("UPDATE rental_equipment SET status='Rented' WHERE id=?",(request.form["equipment_id"],))
            c.commit(); c.close(); audit("rental",cur.lastrowid,"created",None,dict(request.form)); flash("Rental saved. Monthly billing remains subject to Admin review before invoice issue.","success")
        except (ValueError,KeyError) as exc: c.close(); flash(str(exc),"error")
        return redirect(url_for("rentals_module"))
    customers_list=c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall(); equip=c.execute("SELECT id,equipment_name,serial_no,monthly_rate,status FROM rental_equipment ORDER BY equipment_name").fetchall()
    rows=c.execute("SELECT r.*,c.company_name,e.equipment_name FROM rentals r JOIN customers c ON c.id=r.customer_id LEFT JOIN rental_equipment e ON e.id=r.equipment_id ORDER BY r.id DESC").fetchall(); c.close()
    return render_template("operations.html",title="Rental Management",mode="rentals",customers=customers_list,equipment=equip,rows=rows,columns=["company_name","equipment_name","description","start_date","end_date","monthly_rent","status"])


@app.route("/admin/rentals/billing",methods=["GET","POST"])
@login_required
def rental_billing_queue():
    c=db()
    if request.method=="POST":
        month=request.form.get("billing_month",datetime.now().strftime("%Y-%m"))
        try:
            datetime.strptime(month,"%Y-%m")
        except ValueError:
            c.close(); flash("Billing month must be in YYYY-MM format.","error"); return redirect(url_for("rental_billing_queue"))
        month_start=month+"-01"
        from datetime import timedelta
        month_date=datetime.strptime(month,"%Y-%m").date()
        next_month=(month_date.replace(day=28)+timedelta(days=4)).replace(day=1).isoformat()
        # Include active contracts covering any part of the selected month; Admin reviews each draft before issue.
        rentals=c.execute("SELECT * FROM rentals WHERE status='Active' AND start_date<? AND (end_date IS NULL OR end_date>=?)",(next_month,month_start)).fetchall()
        created=0
        for rental in rentals:
            cur=c.execute("INSERT OR IGNORE INTO rental_bills(rental_id,billing_month,amount,gst_rate,gst_type,status,created_at) VALUES(?,?,?,?,?,'Draft',?)",
              (rental["id"],month,rental["monthly_rent"],rental["gst_rate"] or 0,rental["gst_type"] or "CGST+SGST",datetime.now().isoformat(timespec="seconds")))
            created+=cur.rowcount
        c.commit(); c.close(); flash(f"Billing queue prepared for {month}. {created} new draft(s) created; review each before issuing an invoice.","success"); return redirect(url_for("rental_billing_queue"))
    rows=c.execute("SELECT b.*,r.description,r.start_date,r.end_date,c.company_name,e.equipment_name FROM rental_bills b JOIN rentals r ON r.id=b.rental_id JOIN customers c ON c.id=r.customer_id LEFT JOIN rental_equipment e ON e.id=r.equipment_id ORDER BY b.billing_month DESC,b.id DESC").fetchall(); c.close()
    return render_template("operations.html",title="Rental Billing Review Queue",mode="rental_billing",today_month=datetime.now().strftime("%Y-%m"),rows=rows,columns=["billing_month","company_name","equipment_name","description","amount","gst_rate","gst_type","status","invoice_id"])

@app.route("/admin/rentals/billing/<int:bid>/update",methods=["POST"])
@login_required
def update_rental_bill(bid):
    c=db(); bill=c.execute("SELECT * FROM rental_bills WHERE id=?",(bid,)).fetchone()
    if not bill: c.close(); return "Rental bill not found",404
    if bill["status"]!="Draft": c.close(); flash("Only draft rental bills can be edited.","error"); return redirect(url_for("rental_billing_queue"))
    try:
        amount=float(request.form.get("amount") or 0); rate=float(request.form.get("gst_rate") or 0); gst_type=request.form.get("gst_type","CGST+SGST")
        if amount<0 or rate<0 or gst_type not in ("CGST+SGST","IGST"): raise ValueError("Enter valid amount, GST rate and GST type.")
        c.execute("UPDATE rental_bills SET amount=?,gst_rate=?,gst_type=? WHERE id=?",(amount,rate,gst_type,bid)); c.commit(); updated=c.execute("SELECT * FROM rental_bills WHERE id=?",(bid,)).fetchone(); c.close()
        audit("rental_bill",bid,"draft_review_edited",dict(bill),dict(updated)); flash("Rental bill draft updated. Issue it only after review.","success")
    except ValueError as exc: c.close(); flash(str(exc),"error")
    return redirect(url_for("rental_billing_queue"))

@app.route("/admin/rentals/billing/<int:bid>/issue",methods=["POST"])
@login_required
def issue_rental_bill(bid):
    c=db(); bill=c.execute("SELECT b.*,r.customer_id,r.description FROM rental_bills b JOIN rentals r ON r.id=b.rental_id WHERE b.id=?",(bid,)).fetchone()
    if not bill: c.close(); return "Rental bill not found",404
    if bill["status"]!="Draft": c.close(); flash("Only a draft rental bill can be issued.","error"); return redirect(url_for("rental_billing_queue"))
    now=datetime.now(); invoice_no=next_invoice_number(c, now)
    taxable=float(bill["amount"] or 0); rate=float(bill["gst_rate"] or 0)
    if bill["gst_type"]=="IGST": cr=sr=0.0; ir=rate
    else: cr=sr=rate/2; ir=0.0
    cgst=round(taxable*cr/100,2); sgst=round(taxable*sr/100,2); igst=round(taxable*ir/100,2); total=round(taxable+cgst+sgst+igst,2)
    cur=c.execute("INSERT INTO invoices(invoice_no,customer_id,invoice_date,subtotal,cgst,sgst,igst,cgst_rate,sgst_rate,igst_rate,total,status,signed_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      (invoice_no,bill["customer_id"],now.strftime('%Y-%m-%d'),taxable,cgst,sgst,igst,cr,sr,ir,total,"Pending",now.strftime("%d-%m-%Y %I:%M:%S %p"),now.isoformat(timespec="seconds")))
    iid=cur.lastrowid; c.execute("INSERT INTO invoice_items(invoice_id,description,qty,rate,amount,product_id,cost_at_sale) VALUES(?,?,?,?,?,?,?)",(iid,f"Monthly rental — {bill['description']} ({bill['billing_month']})",1,taxable,taxable,None,None))
    c.execute("UPDATE rental_bills SET status='Issued',invoice_id=? WHERE id=?",(iid,bid)); c.execute("UPDATE rentals SET last_billed_month=? WHERE id=?",(bill["billing_month"],bill["rental_id"]))
    c.commit(); c.close(); audit("rental_bill",bid,"issued_after_admin_review",dict(bill),{"invoice_id":iid,"invoice_no":invoice_no})
    try:
        pdf=create_invoice_pdf(iid); c=db(); c.execute("UPDATE invoices SET pdf_path=? WHERE id=?",(pdf,iid)); c.commit(); c.close(); flash("Reviewed rental bill issued as invoice.","success")
    except Exception as exc: flash("Rental invoice issued, but PDF generation failed: "+str(exc),"error")
    return redirect(url_for("invoice_detail",iid=iid))

@app.route("/admin/service-jobs",methods=["GET","POST"])
@login_required
def service_jobs_module():
    c=db()
    if request.method=="POST":
        try:
            cid=int(request.form["customer_id"]); complaint=request.form.get("complaint","").strip()
            if not complaint: raise ValueError("Complaint / service details are required.")
            jobno="SRV-"+datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            cur=c.execute("INSERT INTO service_jobs(job_no,customer_id,category_id,assigned_employee_id,equipment,serial_no,complaint,parts_cost,labour_cost,status,warranty_until,opened_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (jobno,cid,request.form.get("category_id") or None,request.form.get("assigned_employee_id") or None,request.form.get("equipment",""),request.form.get("serial_no",""),complaint,float(request.form.get("parts_cost") or 0),float(request.form.get("labour_cost") or 0),request.form.get("status","Open"),request.form.get("warranty_until") or None,datetime.now().isoformat(timespec="seconds"),request.form.get("notes","")))
            c.commit(); c.close(); audit("service_job",cur.lastrowid,"created",None,{"job_no":jobno,"complaint":complaint}); flash("Repair / service job created.","success")
        except (ValueError,KeyError) as exc: c.close(); flash(str(exc),"error")
        return redirect(url_for("service_jobs_module"))
    customers_list=c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall(); cats=c.execute("SELECT id,name FROM service_categories WHERE active=1 ORDER BY name").fetchall(); staff=c.execute("SELECT id,name FROM employees WHERE active=1 ORDER BY name").fetchall()
    rows=c.execute("SELECT j.*,c.company_name,sc.name category_name,e.name employee_name FROM service_jobs j JOIN customers c ON c.id=j.customer_id LEFT JOIN service_categories sc ON sc.id=j.category_id LEFT JOIN employees e ON e.id=j.assigned_employee_id ORDER BY j.id DESC").fetchall(); c.close()
    return render_template("operations.html",title="Repair / Service Management",mode="service",customers=customers_list,categories=cats,employees=staff,rows=rows,columns=["job_no","company_name","category_name","equipment","serial_no","complaint","employee_name","parts_cost","labour_cost","status","warranty_until"])

@app.route("/admin/quotes",methods=["GET","POST"])
@login_required
def quotes_module():
    c=db()
    if request.method=="POST":
        try:
            cid=int(request.form["customer_id"]); rate=float(request.form.get("gst_rate") or 0)
            if rate<0: raise ValueError("GST rate cannot be negative.")
            gst_type=request.form.get("gst_type","CGST+SGST")
            if gst_type not in ("CGST+SGST","IGST"): gst_type="CGST+SGST"
            descriptions=request.form.getlist("item_description[]"); qtys=request.form.getlist("item_qty[]"); rates=request.form.getlist("item_rate[]"); gst_rates=request.form.getlist("item_gst[]")
            quote_lines=[]; taxable=0.0; gst=0.0
            for d,q,r,g in zip(descriptions,qtys,rates,gst_rates):
                if not d.strip(): continue
                qty=float(q or 0); unit=float(r or 0); gr=float(g or 0)
                if qty<=0 or unit<0 or gr<0: raise ValueError("Each item needs quantity above zero and non-negative price/GST.")
                amount=round(qty*unit,2); tax=round(amount*gr/100,2); taxable+=amount; gst+=tax; quote_lines.append((d.strip(),qty,unit,gr,amount))
            if not quote_lines:
                taxable=float(request.form.get("taxable_amount") or 0); gst=round(taxable*rate/100,2)
            if taxable<0: raise ValueError("Amount cannot be negative.")
            total=round(taxable+gst,2); qno="QTN-"+datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            cur=c.execute("INSERT INTO quotes(quote_no,customer_id,quote_date,valid_until,description,taxable_amount,gst_rate,gst_type,gst_amount,total,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
              (qno,cid,request.form.get("quote_date") or datetime.now().strftime("%Y-%m-%d"),request.form.get("valid_until") or None,request.form.get("description",""),taxable,rate,gst_type,gst,total,request.form.get("status","Draft"),datetime.now().isoformat(timespec="seconds")))
            qid=cur.lastrowid
            for d,qty,unit,gr,amount in quote_lines: c.execute("INSERT INTO quote_items(quote_id,description,qty,rate,gst_rate,amount) VALUES(?,?,?,?,?,?)",(qid,d,qty,unit,gr,amount))
            c.commit(); c.close(); audit("quote",qid,"created",None,{"quote_no":qno,"total":total,"items":len(quote_lines)}); flash("Quotation saved with item-wise pricing and GST.","success")
        except (ValueError,KeyError) as exc: c.close(); flash(str(exc),"error")
        return redirect(url_for("quotes_module"))
    customers_list=c.execute("SELECT id,company_name FROM customers ORDER BY company_name").fetchall(); rows=c.execute("SELECT q.*,c.company_name FROM quotes q JOIN customers c ON c.id=q.customer_id ORDER BY q.id DESC").fetchall(); c.close()
    return render_template("operations.html",title="Quotation / Estimate",mode="quotes",customers=customers_list,rows=rows,columns=["quote_no","company_name","quote_date","valid_until","description","taxable_amount","gst_rate","gst_type","gst_amount","total","status"])


@app.route("/admin/reminders")
@login_required
def warranty_reminders():
    c=db(); today=datetime.now().strftime("%Y-%m-%d"); soon=(datetime.now().date()).replace(day=28)
    from datetime import timedelta
    horizon=(datetime.now().date()+timedelta(days=60)).isoformat()
    products_rows=c.execute("SELECT id,product_name,serial_no,warranty,warranty_until,stock_qty FROM products WHERE warranty_until IS NOT NULL AND warranty_until<>'' AND warranty_until<=? ORDER BY warranty_until",(horizon,)).fetchall()
    jobs_rows=c.execute("SELECT j.*,c.company_name FROM service_jobs j JOIN customers c ON c.id=j.customer_id WHERE j.warranty_until IS NOT NULL AND j.warranty_until<>'' AND j.warranty_until<=? ORDER BY j.warranty_until",(horizon,)).fetchall()
    c.close(); return render_template("operations.html",title="Warranty & Service Reminders",mode="reminders",products=products_rows,service_reminders=jobs_rows,today=today,horizon=horizon)

@app.route("/admin/reports")
@login_required
def reports_module():
    fy=request.args.get("fy",""); start,end="",""
    if fy:
        try:
            year=int(fy); start=f"{year}-04-01"; end=f"{year+1}-04-01"
        except ValueError: fy=""
    if not fy:
        now=datetime.now(); year=now.year if now.month>=4 else now.year-1; start=f"{year}-04-01"; end=f"{year+1}-04-01"; fy=str(year)
    c=db()
    summary={"sales":c.execute("SELECT COALESCE(SUM(total),0) n FROM invoices WHERE invoice_date>=? AND invoice_date<?",(start,end)).fetchone()["n"],
      "gst":c.execute("SELECT COALESCE(SUM(cgst+sgst+igst),0) n FROM invoices WHERE invoice_date>=? AND invoice_date<?",(start,end)).fetchone()["n"],
      "purchases":c.execute("SELECT COALESCE(SUM(amount),0) n FROM purchases WHERE purchase_date>=? AND purchase_date<?",(start,end)).fetchone()["n"],
      "payments":c.execute("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE active=1 AND payment_date>=? AND payment_date<?",(start,end)).fetchone()["n"]}
    c.close(); return render_template("operations.html",title="Reports & Excel Export",mode="reports",fy=fy,start=start,end=end,summary=summary)

@app.route("/admin/reports/export.csv")
@login_required
def export_report_csv():
    import csv, io
    kind=request.args.get("kind","sales")
    allowed={"sales":("SELECT invoice_no,invoice_date,customer_id,subtotal,cgst,sgst,igst,total,status FROM invoices", "invoice_date"),
             "purchases":("SELECT purchase_no,purchase_date,vendor_id,product_id,qty,unit_cost,amount FROM purchases", "purchase_date"),
             "payments":("SELECT id,invoice_id,amount,payment_date,method,reference,active FROM payments", "payment_date"),
             "service":("SELECT job_no,customer_id,equipment,serial_no,complaint,parts_cost,labour_cost,status,warranty_until,opened_at FROM service_jobs", "opened_at"),
             "rentals":("SELECT id,customer_id,description,start_date,end_date,monthly_rent,status FROM rentals", "start_date"),
             "stock":("SELECT sm.id,p.product_name,sm.movement_type,sm.quantity_change,sm.balance_after,sm.reference_type,sm.reference_id,sm.notes,sm.created_at FROM stock_movements sm JOIN products p ON p.id=sm.product_id", "sm.created_at")}
    if kind not in allowed: return "Report type not found",404
    fy=request.args.get("fy","").strip(); start=end=None
    try:
        if fy:
            year=int(fy); start=f"{year}-04-01"; end=f"{year+1}-04-01"
    except ValueError: fy=""
    query,date_col=allowed[kind]; args=[]
    if kind=="payments": query+=" WHERE active=1"
    if start and end:
        query+=(" AND " if " WHERE " in query else " WHERE ")+f" {date_col}>=? AND {date_col}<?"; args=[start,end]
    query+=" ORDER BY "+date_col+" DESC"
    c=db(); cur=c.execute(query,args); rows=cur.fetchall(); headers=[d[0] for d in cur.description]; c.close()
    output=io.StringIO(); writer=csv.writer(output); writer.writerow(headers)
    for row in rows: writer.writerow([row[h] for h in headers])
    from flask import Response
    return Response('\ufeff'+output.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename=pc_services_{kind}_{fy or "all"}.csv'})

@app.route("/admin/stock-movements")
@login_required
def stock_movements_module():
    c=db(); rows=c.execute("SELECT sm.*,p.product_name,p.serial_no FROM stock_movements sm JOIN products p ON p.id=sm.product_id ORDER BY sm.id DESC LIMIT 500").fetchall(); c.close()
    return render_template("operations.html",title="Stock Movement History",mode="logs",rows=rows,columns=["created_at","product_name","serial_no","movement_type","quantity_change","balance_after","reference_type","reference_id","notes"])

@app.route("/admin/service-jobs/<int:jid>/status",methods=["POST"])
@login_required
def update_service_job_status(jid):
    c=db(); job=c.execute("SELECT * FROM service_jobs WHERE id=?",(jid,)).fetchone()
    if not job: c.close(); return "Service job not found",404
    status=request.form.get("status","Open")
    if status not in ("Open","In Progress","Waiting for Parts","Resolved","Closed"): c.close(); flash("Invalid service status.","error"); return redirect(url_for("service_jobs_module"))
    closed_at=datetime.now().isoformat(timespec="seconds") if status in ("Resolved","Closed") else None
    c.execute("UPDATE service_jobs SET status=?,closed_at=? WHERE id=?",(status,closed_at,jid)); c.commit(); updated=c.execute("SELECT * FROM service_jobs WHERE id=?",(jid,)).fetchone(); c.close()
    audit("service_job",jid,"status_updated",dict(job),dict(updated)); flash("Service job status updated.","success"); return redirect(url_for("service_jobs_module"))

@app.route("/admin/rentals/<int:rid>/return",methods=["POST"])
@login_required
def return_rental(rid):
    c=db(); rental=c.execute("SELECT * FROM rentals WHERE id=?",(rid,)).fetchone()
    if not rental: c.close(); return "Rental not found",404
    if rental["status"]!="Active": c.close(); flash("This rental is not active.","error"); return redirect(url_for("rentals_module"))
    c.execute("UPDATE rentals SET status='Returned',end_date=COALESCE(end_date,?) WHERE id=?",(datetime.now().strftime("%Y-%m-%d"),rid))
    if rental["equipment_id"]: c.execute("UPDATE rental_equipment SET status='Available' WHERE id=?",(rental["equipment_id"],))
    c.commit(); updated=c.execute("SELECT * FROM rentals WHERE id=?",(rid,)).fetchone(); c.close(); audit("rental",rid,"returned",dict(rental),dict(updated)); flash("Rental marked returned; linked equipment set to Available.","success"); return redirect(url_for("rentals_module"))

@app.route("/admin/quote-requests/<int:rid>/status",methods=["POST"])
@login_required
def update_quote_request_status(rid):
    c=db(); item=c.execute("SELECT * FROM quote_requests WHERE id=?",(rid,)).fetchone()
    if not item: c.close(); return "Quote request not found",404
    status=request.form.get("status","New")
    if status not in ("New","In Review","Quoted","Converted","Closed","Spam"): c.close(); flash("Invalid quote request status.","error"); return redirect(url_for("quote_requests_module"))
    c.execute("UPDATE quote_requests SET status=? WHERE id=?",(status,rid)); c.commit(); updated=c.execute("SELECT * FROM quote_requests WHERE id=?",(rid,)).fetchone(); c.close(); audit("quote_request",rid,"status_updated",dict(item),dict(updated)); flash("Quote request status updated.","success"); return redirect(url_for("quote_requests_module"))

@app.route("/admin/email-logs")
@login_required
def email_logs_module():
    c=db(); rows=c.execute("SELECT * FROM email_logs ORDER BY id DESC LIMIT 250").fetchall(); c.close()
    return render_template("operations.html",title="Email Delivery Logs",mode="logs",rows=rows,columns=["created_at","kind","recipient","subject","status","error"])

@app.route("/admin/audit-log")
@login_required
def audit_logs_module():
    c=db(); rows=c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 300").fetchall(); c.close()
    return render_template("operations.html",title="Audit History",mode="logs",rows=rows,columns=["created_at","actor","entity_type","entity_id","action","before_json","after_json"])

@app.route("/get-a-quote",methods=["POST"])
def get_a_quote():
    init_db()
    name=request.form.get("name","").strip(); email=request.form.get("email","").strip(); phone=request.form.get("phone","").strip(); service=request.form.get("service","").strip(); message=request.form.get("message","").strip()
    if not name or not email:
        flash("Please enter your name and email to request a quote.","error"); return redirect(url_for("home")+"#contact")
    c=db(); cur=c.execute("INSERT INTO quote_requests(name,email,phone,service,message,status,created_at) VALUES(?,?,?,?,?,'New',?)",(name,email,phone,service,message,datetime.now().isoformat(timespec="seconds"))); rid=cur.lastrowid; c.commit(); c.close()
    s=settings(); admin_email=s.get("quote_admin_email") or s.get("company_email") or "Ranveer@pcservicess.com"
    admin_body=f"New website quote request #{rid}\nName: {name}\nEmail: {email}\nPhone: {phone}\nService: {service}\nMessage: {message}"
    admin_ok,admin_err=send_business_email(admin_email,f"New website quote request #{rid}",admin_body,"quote_admin_notification")
    customer_ok,customer_err=send_business_email(email,"We received your PC Services quote request",f"Dear {name},\n\nThank you for contacting PC Services. We have received your request for: {service or 'IT services'}. Our team will review it and get back to you.","quote_customer_confirmation")
    if admin_ok and customer_ok: flash("Thank you! Your request is saved, and confirmation emails were sent.","success")
    elif admin_ok or customer_ok: flash("Your quote request is saved. One email could not be sent; the admin can check Email Delivery Logs.","success")
    else: flash("Your quote request is saved. Email delivery is pending SMTP configuration; the admin can check Email Delivery Logs.","success")
    return redirect(url_for("home")+"#contact")

@app.route("/admin/quote-requests")
@login_required
def quote_requests_module():
    c=db(); rows=c.execute("SELECT * FROM quote_requests ORDER BY id DESC").fetchall(); c.close()
    return render_template("operations.html",title="Website Quote Requests",mode="logs",rows=rows,columns=["created_at","name","email","phone","service","message","status"])


@app.route("/admin/backups", methods=["GET", "POST"])
@login_required
def backup_manager():
    if session.get("role") != "admin":
        return "Access denied: Admin only.", 403
    if request.method == "POST":
        action = request.form.get("action", "")
        if action == "create":
            try:
                path = create_backup("manual")
                flash("Backup created successfully: " + os.path.basename(path), "success")
            except Exception as exc:
                flash("Backup failed: " + str(exc), "error")
            return redirect(url_for("backup_manager"))
        if action == "restore":
            filename = os.path.basename(request.form.get("filename", ""))
            path = os.path.join(BACKUP_DIR, filename)
            if not filename.endswith(".zip") or not os.path.isfile(path):
                flash("Selected backup file was not found.", "error")
                return redirect(url_for("backup_manager"))
            try:
                with zipfile.ZipFile(path, "r") as zf:
                    info = zf.getinfo("pc_services.db")
                    if info.file_size <= 0 or info.file_size > 2_000_000_000:
                        raise ValueError("Backup database size is invalid.")
                    temp_restore = os.path.join(BACKUP_DIR, "restore_candidate.db")
                    with zf.open("pc_services.db") as src, open(temp_restore, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                check = sqlite3.connect(temp_restore)
                try:
                    result = check.execute("PRAGMA integrity_check").fetchone()[0]
                    if result != "ok": raise ValueError("Backup database integrity check failed.")
                finally: check.close()
                if os.path.exists(DB) and os.path.getsize(DB) > 0:
                    create_backup("before_restore")
                os.replace(temp_restore, DB)
                with zipfile.ZipFile(path, "r") as zf:
                    for member in zf.namelist():
                        if member.startswith(("static/uploads/", "invoices/", "quotes/")) and not member.endswith("/"):
                            safe = os.path.normpath(member)
                            if safe.startswith("..") or os.path.isabs(safe): continue
                            dest = os.path.join(BASE, safe)
                            os.makedirs(os.path.dirname(dest), exist_ok=True)
                            with zf.open(member) as src, open(dest, "wb") as dst: shutil.copyfileobj(src, dst)
                session.clear()
                flash("Backup restored. A safety backup of current data was created before restore. Please sign in again.", "success")
                return redirect(url_for("login"))
            except Exception as exc:
                try:
                    if os.path.exists(os.path.join(BACKUP_DIR, "restore_candidate.db")): os.remove(os.path.join(BACKUP_DIR, "restore_candidate.db"))
                except OSError: pass
                flash("Restore failed: " + str(exc), "error")
            return redirect(url_for("backup_manager"))
    files=[]
    try:
        for name in os.listdir(BACKUP_DIR):
            full=os.path.join(BACKUP_DIR,name)
            if name.endswith(".zip") and os.path.isfile(full):
                files.append({"name":name,"size":os.path.getsize(full),"date":datetime.fromtimestamp(os.path.getmtime(full)).strftime("%d-%b-%Y %I:%M %p")})
    except OSError: pass
    files.sort(key=lambda x:x["name"], reverse=True)
    return render_template("backups.html", files=files, latest=files[0]["date"] if files else "No backups yet", backup_dir=BACKUP_DIR)

@app.route("/admin/backups/<path:filename>/download")
@login_required
def download_backup(filename):
    if session.get("role") != "admin": return "Access denied: Admin only.", 403
    safe=os.path.basename(filename)
    path=os.path.join(BACKUP_DIR,safe)
    if not safe.endswith(".zip") or not os.path.isfile(path): return "Backup not found",404
    return send_file(path, as_attachment=True, download_name=safe)


if __name__=="__main__":
    init_db()
    threading.Thread(target=_daily_backup_worker, daemon=True, name="pc-services-daily-backup").start()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=os.environ.get("FLASK_DEBUG") == "1")
