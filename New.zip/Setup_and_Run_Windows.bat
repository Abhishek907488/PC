@echo off
setlocal
cd /d "%~dp0"
echo Installing or checking required Python packages...
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. Check Python and internet access.
  pause
  exit /b 1
)
echo Starting PC SERVICES Business Management System...
py app.py
pause
